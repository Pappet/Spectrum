// Mock scan data — realistic apartment-scale busy state.

const WIFI_NETWORKS = [
  { ssid: 'FRITZ!Box 7590 MN', bssid: '3C:A6:2F:1A:44:90', rssi: -42, freq: 5180, channel: 36, band: '5', security: 'WPA3', connected: true, wps: false, vendor: 'AVM', standard: 'Wi-Fi 6', width: '80', distance: 3.2 },
  { ssid: 'FRITZ!Box 7590 MN',  bssid: '3C:A6:2F:1A:44:91', rssi: -58, freq: 2437, channel: 6,  band: '2.4', security: 'WPA3', connected: false, wps: false, vendor: 'AVM', standard: 'Wi-Fi 6', width: '20', distance: 7.1 },
  { ssid: 'Vodafone-1C4F',      bssid: '8C:0C:90:1C:4F:AA', rssi: -67, freq: 2412, channel: 1,  band: '2.4', security: 'WPA2', connected: false, wps: true,  vendor: 'Vodafone', standard: 'Wi-Fi 5', width: '20', distance: 12.4 },
  { ssid: 'Telekom_FON',        bssid: 'AC:22:0B:9D:12:03', rssi: -71, freq: 5745, channel: 149,band: '5',   security: 'WPA2', connected: false, wps: false, vendor: 'Deutsche Telekom', standard: 'Wi-Fi 5', width: '40', distance: 18.2 },
  { ssid: 'eduroam',            bssid: '00:1F:A3:44:2C:1E', rssi: -74, freq: 2462, channel: 11, band: '2.4', security: 'WPA2-EAP', connected: false, wps: false, vendor: 'Aruba', standard: 'Wi-Fi 5', width: '20', distance: 22.0 },
  { ssid: 'MagentaWLAN-4KJH',   bssid: 'B0:52:16:88:10:F2', rssi: -78, freq: 2437, channel: 6,  band: '2.4', security: 'WPA2', connected: false, wps: false, vendor: 'Huawei', standard: 'Wi-Fi 5', width: '20', distance: 28.0 },
  { ssid: '(hidden)',           bssid: 'E0:1C:FC:33:4A:21', rssi: -82, freq: 2412, channel: 1,  band: '2.4', security: 'WPA2', connected: false, wps: false, vendor: 'TP-Link', standard: 'Wi-Fi 5', width: '20', distance: 34.0 },
  { ssid: 'Nachbar_2.4',        bssid: '50:C7:BF:A1:09:33', rssi: -85, freq: 2462, channel: 11, band: '2.4', security: 'WPA2', connected: false, wps: false, vendor: 'TP-Link', standard: 'Wi-Fi 4', width: '20', distance: 41.0 },
  { ssid: 'o2-WLAN38',          bssid: '74:DA:38:9A:2C:11', rssi: -88, freq: 5220, channel: 44, band: '5',   security: 'WPA2', connected: false, wps: false, vendor: 'Edimax', standard: 'Wi-Fi 5', width: '40', distance: 51.0 },
  { ssid: 'Gast_Bauer',         bssid: 'F4:F5:E8:30:AA:01', rssi: -91, freq: 2437, channel: 6,  band: '2.4', security: 'WPA2', connected: false, wps: false, vendor: 'Google', standard: 'Wi-Fi 5', width: '20', distance: 62.0 },
  { ssid: 'IoT-Lab-Legacy',     bssid: 'C0:FF:EE:12:34:56', rssi: -79, freq: 2437, channel: 6,  band: '2.4', security: 'WEP',  connected: false, wps: false, vendor: 'Unknown', standard: 'Wi-Fi 4', width: '20', distance: 30.1 },
  { ssid: 'Printer-Direct',     bssid: '00:22:58:AB:CD:EF', rssi: -73, freq: 2412, channel: 1,  band: '2.4', security: 'Open', connected: false, wps: false, vendor: 'Brother', standard: 'Wi-Fi 4', width: '20', distance: 20.0 },
];

const BT_DEVICES = [
  { name: 'Pixel Buds Pro', addr: 'A4:83:E7:11:22:33', rssi: -38, type: 'BLE',     bond: 'BONDED',     minorClass: 'Headphones', vendor: 'Google' },
  { name: 'LG OLED C3',     addr: 'B8:AD:3E:4F:12:9A', rssi: -52, type: 'DUAL',    bond: 'BONDED',     minorClass: 'TV',         vendor: 'LG Electronics' },
  { name: 'MX Master 3S',   addr: '00:1F:20:54:3C:EE', rssi: -44, type: 'BLE',     bond: 'BONDED',     minorClass: 'Mouse',      vendor: 'Logitech' },
  { name: 'Tile Mate',      addr: 'D0:03:4B:09:77:88', rssi: -62, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'Tracker',    vendor: 'Tile' },
  { name: 'Mi Band 8',      addr: 'C8:47:8C:11:34:56', rssi: -55, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'Wearable',   vendor: 'Xiaomi' },
  { name: 'Bose QC45',      addr: '04:52:C7:3C:FE:01', rssi: -68, type: 'CLASSIC', bond: 'NOT_BONDED', minorClass: 'Headphones', vendor: 'Bose' },
  { name: '—',              addr: '5C:F3:70:88:12:33', rssi: -72, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'Beacon',     vendor: 'Apple' },
  { name: 'ESP32-Sensor',   addr: '30:AE:A4:22:11:00', rssi: -77, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'IoT',        vendor: 'Espressif' },
  { name: 'Galaxy Watch 6', addr: 'E4:5F:01:AA:BB:CC', rssi: -49, type: 'DUAL',    bond: 'NOT_BONDED', minorClass: 'Wearable',   vendor: 'Samsung' },
  { name: '—',              addr: '6C:AD:F8:00:00:12', rssi: -85, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'Unknown',    vendor: 'Chipolo' },
  { name: 'Sony WH-1000XM5',addr: 'AC:80:0A:FF:22:11', rssi: -59, type: 'CLASSIC', bond: 'BONDED',     minorClass: 'Headphones', vendor: 'Sony' },
  { name: 'Hue Bridge',     addr: '00:17:88:33:44:55', rssi: -63, type: 'BLE',     bond: 'NOT_BONDED', minorClass: 'Hub',        vendor: 'Philips' },
];

const LAN_DEVICES = [
  { ip: '192.168.1.1',   mac: '3C:A6:2F:1A:44:90', name: 'fritz.box',       vendor: 'AVM',              role: 'Router',    ports: [80, 443, 5060] },
  { ip: '192.168.1.20',  mac: 'F0:72:EA:00:11:22', name: 'macbook-pro',     vendor: 'Apple',            role: 'Laptop',    ports: [22, 3000, 5000] },
  { ip: '192.168.1.24',  mac: '70:88:6B:AA:BB:CC', name: 'LGwebOSTV',       vendor: 'LG',               role: 'TV',        ports: [3000, 8080] },
  { ip: '192.168.1.31',  mac: '00:22:58:AB:CD:EF', name: 'BRN882AB',        vendor: 'Brother',          role: 'Printer',   ports: [80, 515, 631, 9100] },
  { ip: '192.168.1.42',  mac: 'B8:27:EB:34:12:09', name: 'raspberrypi',     vendor: 'Raspberry Pi',     role: 'Server',    ports: [22, 80, 8123] },
  { ip: '192.168.1.55',  mac: '30:AE:A4:22:11:00', name: 'esp32-balcony',   vendor: 'Espressif',        role: 'IoT',       ports: [80] },
  { ip: '192.168.1.64',  mac: 'D4:3D:7E:09:12:34', name: 'chromecast-tv',   vendor: 'Google',           role: 'Cast',      ports: [8008, 8009] },
  { ip: '192.168.1.78',  mac: '00:17:88:33:44:55', name: 'Philips-hue',     vendor: 'Philips',          role: 'Hub',       ports: [80, 443] },
  { ip: '192.168.1.81',  mac: 'F8:1A:67:00:11:22', name: 'TP-LINK-Switch',  vendor: 'TP-Link',          role: 'Switch',    ports: [22, 80] },
  { ip: '192.168.1.90',  mac: 'AC:DE:48:00:11:22', name: 'iPhone-Anna',     vendor: 'Apple',            role: 'Phone',     ports: [] },
  { ip: '192.168.1.101', mac: 'A4:C3:F0:12:34:56', name: 'NAS-Synology',    vendor: 'Synology',         role: 'NAS',       ports: [22, 80, 443, 5000, 5001] },
  { ip: '192.168.1.112', mac: 'B4:E6:2D:AA:BB:00', name: 'Xiaomi-Mi-Robot', vendor: 'Xiaomi',           role: 'IoT',       ports: [80, 8080] },
];

const CHANNEL_2GHZ = [
  { ch: 1,  count: 3, util: 78 },
  { ch: 2,  count: 0, util: 22 },
  { ch: 3,  count: 0, util: 34 },
  { ch: 4,  count: 0, util: 48 },
  { ch: 5,  count: 1, util: 62 },
  { ch: 6,  count: 4, util: 92 },
  { ch: 7,  count: 0, util: 71 },
  { ch: 8,  count: 0, util: 54 },
  { ch: 9,  count: 0, util: 38 },
  { ch: 10, count: 1, util: 48 },
  { ch: 11, count: 2, util: 70 },
];

const CHANNEL_5GHZ = [
  { ch: 36,  count: 1, util: 42 },
  { ch: 40,  count: 0, util: 8  },
  { ch: 44,  count: 1, util: 28 },
  { ch: 48,  count: 0, util: 12 },
  { ch: 52,  count: 0, util: 4  },
  { ch: 100, count: 0, util: 6  },
  { ch: 149, count: 1, util: 32 },
  { ch: 153, count: 0, util: 10 },
  { ch: 157, count: 0, util: 18 },
  { ch: 161, count: 0, util: 8  },
];

// Live monitor: last 60 samples (rssi dBm, latency ms gateway + 8.8.8.8)
function genMonitorData() {
  const rssi = [];
  const gw = [];
  const pub = [];
  let r = -45, g = 2.4, p = 14;
  for (let i = 0; i < 60; i++) {
    r += (Math.random() - 0.5) * 3;
    r = Math.max(-65, Math.min(-38, r));
    g += (Math.random() - 0.5) * 0.8;
    g = Math.max(0.8, Math.min(5.5, g));
    p += (Math.random() - 0.5) * 4;
    p = Math.max(8, Math.min(28, p));
    rssi.push(+r.toFixed(1));
    gw.push(+g.toFixed(2));
    pub.push(+p.toFixed(1));
  }
  return { rssi, gw, pub };
}

// Security audit findings
const AUDIT_FINDINGS = [
  { severity: 'CRIT',  title: 'WEP encryption detected', target: 'IoT-Lab-Legacy', note: 'Deprecated; crackable in minutes.' },
  { severity: 'HIGH',  title: 'Open network broadcasting', target: 'Printer-Direct', note: 'No authentication required.' },
  { severity: 'HIGH',  title: 'WPS enabled (PIN mode)', target: 'Vodafone-1C4F', note: 'Vulnerable to Pixie-Dust.' },
  { severity: 'MED',   title: 'WPA2 (no WPA3 fallback)', target: '6 networks', note: 'Consider WPA3-SAE migration.' },
  { severity: 'MED',   title: 'Telnet (23) exposed', target: '192.168.1.81', note: 'Cleartext credentials.' },
  { severity: 'LOW',   title: 'Default admin page reachable', target: '192.168.1.1', note: 'HTTP on port 80.' },
  { severity: 'INFO',  title: '12 BLE beacons advertising', target: 'Environment', note: 'Normal for dense area.' },
];

// GATT services/characteristics for BLE explorer (Pixel Buds Pro example)
const GATT_TREE = [
  { uuid: '1800', name: 'Generic Access', cat: 'System', chars: [
    { uuid: '2A00', name: 'Device Name', props: ['R'], value: 'Pixel Buds Pro' },
    { uuid: '2A01', name: 'Appearance',  props: ['R'], value: '0x03C0 · Earbuds' },
    { uuid: '2A04', name: 'Peripheral Pref. Connection', props: ['R'], value: '7.5-30ms / 0 / 4s' },
  ]},
  { uuid: '1801', name: 'Generic Attribute', cat: 'System', chars: [
    { uuid: '2A05', name: 'Service Changed', props: ['I'], value: '—' },
  ]},
  { uuid: '180A', name: 'Device Information', cat: 'System', chars: [
    { uuid: '2A29', name: 'Manufacturer Name', props: ['R'], value: 'Google' },
    { uuid: '2A24', name: 'Model Number',      props: ['R'], value: 'GA03373' },
    { uuid: '2A25', name: 'Serial Number',     props: ['R'], value: '5H2****F9' },
    { uuid: '2A26', name: 'Firmware Revision', props: ['R'], value: '6.120.1' },
    { uuid: '2A27', name: 'Hardware Revision', props: ['R'], value: 'A01' },
  ]},
  { uuid: '180F', name: 'Battery Service', cat: 'Health/Power', chars: [
    { uuid: '2A19', name: 'Battery Level', props: ['R','N'], value: '87%' },
  ]},
  { uuid: 'FE2C', name: 'Google Fast Pair', cat: 'Vendor', chars: [
    { uuid: 'FE2C-1234', name: 'Model ID',        props: ['R'], value: '0x0A0B0C' },
    { uuid: 'FE2C-1235', name: 'Key-based Pairing', props: ['W','N'], value: '—' },
    { uuid: 'FE2C-1236', name: 'Passkey',          props: ['W','N'], value: '—' },
  ]},
  { uuid: 'FDF0', name: 'Custom (undocumented)', cat: 'Vendor', chars: [
    { uuid: 'FDF0-A001', name: 'Control Point', props: ['W','N'], value: '—' },
    { uuid: 'FDF0-A002', name: 'Status',        props: ['R','N'], value: '0x01 IN_EAR' },
  ]},
];

// Inventory — expanded pool with custom labels, favorites, first/last seen
const INVENTORY = [
  { kind: 'wifi', id: '3C:A6:2F:1A:44:90', label: 'Home router', name: 'FRITZ!Box 7590 MN', meta: '5GHz · WPA3', fav: true,  sessions: 142, last: '2m ago',  first: '5 months ago' },
  { kind: 'bt',   id: 'A4:83:E7:11:22:33', label: 'My buds',     name: 'Pixel Buds Pro',     meta: 'BLE · bonded', fav: true,  sessions: 88,  last: 'now',     first: '4 months ago' },
  { kind: 'lan',  id: '192.168.1.101',     label: 'Backup NAS',  name: 'NAS-Synology',       meta: '5 open ports', fav: true,  sessions: 41,  last: '12m ago', first: '3 months ago' },
  { kind: 'wifi', id: '8C:0C:90:1C:4F:AA', label: '',            name: 'Vodafone-1C4F',      meta: '2.4GHz · WPA2 · WPS', fav: false, sessions: 33, last: '2m ago', first: '2 months ago' },
  { kind: 'bt',   id: 'B8:AD:3E:4F:12:9A', label: 'Living room', name: 'LG OLED C3',         meta: 'Dual · bonded', fav: true, sessions: 61, last: '30m ago', first: '3 months ago' },
  { kind: 'lan',  id: '192.168.1.42',      label: 'Home Assistant', name: 'raspberrypi',     meta: 'Server · :8123', fav: true, sessions: 58, last: 'now',   first: '6 months ago' },
  { kind: 'wifi', id: 'AC:22:0B:9D:12:03', label: '',            name: 'Telekom_FON',        meta: '5GHz · WPA2', fav: false, sessions: 12, last: '2m ago', first: '6 weeks ago' },
  { kind: 'bt',   id: '00:1F:20:54:3C:EE', label: 'Work mouse',  name: 'MX Master 3S',       meta: 'BLE · bonded', fav: true, sessions: 72, last: 'now', first: '4 months ago' },
  { kind: 'lan',  id: '192.168.1.20',      label: 'Work laptop', name: 'macbook-pro',        meta: 'Laptop · Apple', fav: true, sessions: 94, last: 'now', first: '7 months ago' },
  { kind: 'wifi', id: 'B0:52:16:88:10:F2', label: '',            name: 'MagentaWLAN-4KJH',   meta: '2.4GHz · WPA2', fav: false, sessions: 8, last: '2m ago', first: '3 weeks ago' },
  { kind: 'bt',   id: 'C0:FF:EE:12:34:56', label: '',            name: 'ESP32-Sensor',       meta: 'BLE · IoT', fav: false, sessions: 4, last: '5h ago', first: '2 weeks ago' },
  { kind: 'lan',  id: '192.168.1.31',      label: 'Printer',     name: 'BRN882AB',           meta: 'Printer · 4 ports', fav: false, sessions: 19, last: '3h ago', first: '5 months ago' },
  { kind: 'wifi', id: 'E0:1C:FC:33:4A:21', label: '',            name: '(hidden)',           meta: '2.4GHz · WPA2', fav: false, sessions: 2, last: '2m ago', first: '1 week ago' },
  { kind: 'bt',   id: 'D0:03:4B:09:77:88', label: '',            name: 'Tile Mate',          meta: 'BLE · tracker', fav: false, sessions: 3, last: '1d ago', first: '1 week ago' },
];

// Wardriving map — points with latlon projected to a fake grid
const WARDRIVING_POINTS = [
  { id: 'p1', x: 0.42, y: 0.38, ssid: 'FRITZ!Box 7590 MN', rssi: -42, security: 'WPA3' },
  { id: 'p2', x: 0.48, y: 0.40, ssid: 'FRITZ!Box 7590 MN', rssi: -58, security: 'WPA3' },
  { id: 'p3', x: 0.55, y: 0.43, ssid: 'Vodafone-1C4F',     rssi: -67, security: 'WPA2' },
  { id: 'p4', x: 0.62, y: 0.35, ssid: 'Telekom_FON',       rssi: -71, security: 'WPA2' },
  { id: 'p5', x: 0.30, y: 0.52, ssid: 'eduroam',           rssi: -74, security: 'WPA2-EAP' },
  { id: 'p6', x: 0.33, y: 0.60, ssid: 'MagentaWLAN-4KJH',  rssi: -78, security: 'WPA2' },
  { id: 'p7', x: 0.68, y: 0.58, ssid: 'IoT-Lab-Legacy',    rssi: -79, security: 'WEP' },
  { id: 'p8', x: 0.72, y: 0.62, ssid: 'Printer-Direct',    rssi: -73, security: 'Open' },
  { id: 'p9', x: 0.25, y: 0.30, ssid: 'o2-WLAN38',         rssi: -88, security: 'WPA2' },
  { id: 'p10',x: 0.52, y: 0.70, ssid: 'Gast_Bauer',        rssi: -91, security: 'WPA2' },
  { id: 'p11',x: 0.78, y: 0.30, ssid: 'Nachbar_2.4',       rssi: -85, security: 'WPA2' },
  { id: 'p12',x: 0.60, y: 0.50, ssid: '(hidden)',          rssi: -82, security: 'WPA2' },
];

// Track polyline
const WARDRIVING_TRACK = [
  [0.15, 0.25],[0.22,0.28],[0.30,0.32],[0.38,0.36],[0.46,0.39],
  [0.54,0.43],[0.62,0.40],[0.68,0.44],[0.73,0.52],[0.72,0.60],
  [0.65,0.63],[0.55,0.68],[0.48,0.70],[0.38,0.63],[0.30,0.58],
  [0.25,0.50],[0.20,0.42],[0.18,0.33],
];

Object.assign(window, {
  WIFI_NETWORKS, BT_DEVICES, LAN_DEVICES,
  CHANNEL_2GHZ, CHANNEL_5GHZ, genMonitorData, AUDIT_FINDINGS,
  GATT_TREE, INVENTORY, WARDRIVING_POINTS, WARDRIVING_TRACK,
});
