// Shared primitives: phone shell, status bar, gesture nav, icons, utilities.

// Utility: bar position by dBm (-30 strong … -95 weak)
function rssiPct(rssi) {
  const clamped = Math.max(-95, Math.min(-30, rssi));
  return (clamped + 95) / 65; // 0..1
}

function rssiBars(rssi) {
  if (rssi >= -55) return 4;
  if (rssi >= -67) return 3;
  if (rssi >= -75) return 2;
  if (rssi >= -85) return 1;
  return 0;
}

// A minimal stroke-based icon set (no decorative SVG drawing — these are glyphs).
const Icon = ({ name, size = 18, color = 'currentColor', strokeWidth = 1.6 }) => {
  const paths = {
    wifi:    <><path d="M2 9a15 15 0 0 1 20 0"/><path d="M5 13a10 10 0 0 1 14 0"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><circle cx="12" cy="20" r="1" fill={color} stroke="none"/></>,
    bt:      <><path d="M7 7l10 10-5 5V2l5 5L7 17"/></>,
    lan:     <><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M7 20h10M12 16v4"/></>,
    monitor: <><path d="M3 12l4-6 4 10 4-8 3 4h3"/></>,
    inventory:<><path d="M3 7h18M3 12h18M3 17h18"/><circle cx="6" cy="7" r="0.8" fill={color} stroke="none"/><circle cx="6" cy="12" r="0.8" fill={color} stroke="none"/><circle cx="6" cy="17" r="0.8" fill={color} stroke="none"/></>,
    shield:  <><path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6l8-3z"/></>,
    refresh: <><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/></>,
    search:  <><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></>,
    download:<><path d="M12 3v12m0 0l-4-4m4 4l4-4"/><path d="M4 21h16"/></>,
    chevron: <><path d="M6 9l6 6 6-6"/></>,
    close:   <><path d="M5 5l14 14M19 5L5 19"/></>,
    lock:    <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    unlock:  <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.5-1.5"/></>,
    dot:     <circle cx="12" cy="12" r="3" fill={color} stroke="none"/>,
    filter:  <><path d="M3 5h18l-7 9v5l-4 2v-7L3 5z"/></>,
    plus:    <><path d="M12 5v14M5 12h14"/></>,
    star:    <><path d="M12 3l3 6 6 1-4.5 4 1 6-5.5-3-5.5 3 1-6L3 10l6-1z"/></>,
    map:     <><path d="M9 4l-6 2v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/></>,
    settings:<><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.15-1.4l2-1.5-2-3.5-2.4.9a7 7 0 0 0-2.4-1.4L13.5 3h-3l-.55 2.1a7 7 0 0 0-2.4 1.4l-2.4-.9-2 3.5 2 1.5A7 7 0 0 0 5 12c0 .48.05.95.15 1.4l-2 1.5 2 3.5 2.4-.9a7 7 0 0 0 2.4 1.4L10.5 21h3l.55-2.1a7 7 0 0 0 2.4-1.4l2.4.9 2-3.5-2-1.5c.1-.45.15-.92.15-1.4z"/></>,
    power:   <><path d="M12 3v9"/><path d="M5.6 7A9 9 0 1 0 18.4 7"/></>,
    chart:   <><path d="M3 21V3M3 21h18"/><rect x="6"  y="13" width="2.5" height="6"/><rect x="10.5" y="8"  width="2.5" height="11"/><rect x="15" y="15" width="2.5" height="4"/></>,
    signal:  <><rect x="3"  y="16" width="3" height="5"/><rect x="8"  y="12" width="3" height="9"/><rect x="13" y="7"  width="3" height="14"/><rect x="18" y="3"  width="3" height="18"/></>,
    printer: <><path d="M6 9V3h12v6M6 18H4v-6h16v6h-2M6 14h12v7H6z"/></>,
    tv:      <><rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8"/></>,
    headphones: <><path d="M4 14a8 8 0 1 1 16 0"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></>,
    watch:   <><rect x="7" y="7" width="10" height="10" rx="2"/><path d="M9 7V3h6v4M9 17v4h6v-4"/></>,
    iot:     <><rect x="5" y="7" width="14" height="10" rx="2"/><path d="M9 3v4M15 3v4M9 21v-4M15 21v-4M3 10h2M3 14h2M19 10h2M19 14h2"/></>,
    mouse:   <><rect x="7" y="3" width="10" height="18" rx="5"/><path d="M12 7v4"/></>,
    tracker: <><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/></>,
    hub:     <><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="9"/></>,
    phone:   <><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M11 18h2"/></>,
    laptop:  <><rect x="4" y="5" width="16" height="10" rx="1"/><path d="M2 19h20"/></>,
    server:  <><rect x="4" y="4" width="16" height="7" rx="1"/><rect x="4" y="13" width="16" height="7" rx="1"/><circle cx="8" cy="7.5" r="0.7" fill={color} stroke="none"/><circle cx="8" cy="16.5" r="0.7" fill={color} stroke="none"/></>,
    router:  <><rect x="3" y="13" width="18" height="7" rx="1.5"/><path d="M12 13V9M12 9l-4-3M12 9l4-3M12 6V3"/><circle cx="8" cy="16.5" r="0.6" fill={color} stroke="none"/><circle cx="11" cy="16.5" r="0.6" fill={color} stroke="none"/></>,
    nas:     <><rect x="4" y="4" width="16" height="16" rx="1"/><path d="M8 8v8M12 8v8M16 8v8"/></>,
    cast:    <><path d="M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6"/><path d="M2 12a8 8 0 0 1 8 8M2 16a4 4 0 0 1 4 4M2 20h.01"/></>,
    switchIcon: <><rect x="3" y="8" width="18" height="8" rx="1"/><circle cx="7" cy="12" r="0.7" fill={color} stroke="none"/><circle cx="11" cy="12" r="0.7" fill={color} stroke="none"/><circle cx="15" cy="12" r="0.7" fill={color} stroke="none"/><circle cx="19" cy="12" r="0.7" fill={color} stroke="none"/></>,
    beacon:  <><circle cx="12" cy="12" r="3"/><path d="M8 8a6 6 0 0 0 0 8M16 8a6 6 0 0 1 0 8M5 5a10 10 0 0 0 0 14M19 5a10 10 0 0 1 0 14"/></>,
    more:    <><circle cx="5" cy="12" r="1.5" fill={color} stroke="none"/><circle cx="12" cy="12" r="1.5" fill={color} stroke="none"/><circle cx="19" cy="12" r="1.5" fill={color} stroke="none"/></>,
    play:    <><path d="M6 4l14 8-14 8z" fill={color}/></>,
    pause:   <><rect x="6" y="4" width="4" height="16" fill={color} stroke="none"/><rect x="14" y="4" width="4" height="16" fill={color} stroke="none"/></>,
    check:   <><path d="M4 12l5 5L20 6"/></>,
    arrow:   <><path d="M5 12h14M13 6l6 6-6 6"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
      {paths[name] || null}
    </svg>
  );
};

// Map LAN role → icon
function lanRoleIcon(role) {
  return ({
    Router: 'router', Laptop: 'laptop', TV: 'tv', Printer: 'printer',
    Server: 'server', IoT: 'iot', Cast: 'cast', Hub: 'hub',
    Switch: 'switchIcon', Phone: 'phone', NAS: 'nas',
  }[role] || 'dot');
}

function btTypeIcon(minorClass) {
  return ({
    Headphones: 'headphones', TV: 'tv', Mouse: 'mouse',
    Tracker: 'tracker', Wearable: 'watch', Beacon: 'beacon',
    IoT: 'iot', Hub: 'hub', Unknown: 'dot',
  }[minorClass] || 'dot');
}

// Phone frame — generic, skin via `skin` object
function PhoneShell({ skin, children, statusBarContent, navContent }) {
  return (
    <div style={{
      width: 412, height: 892, borderRadius: 40, overflow: 'hidden',
      background: skin.surface,
      border: `1px solid ${skin.frameBorder}`,
      outline: `10px solid ${skin.bezel}`,
      boxShadow: '0 40px 80px -30px rgba(0,0,0,0.45), 0 0 0 1px rgba(0,0,0,0.6)',
      display: 'flex', flexDirection: 'column', position: 'relative',
      fontFamily: skin.fontBody,
      color: skin.onSurface,
    }}>
      {/* status bar */}
      <div style={{
        height: 38, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 22px', position: 'relative', flexShrink: 0,
        fontFamily: skin.fontMono, fontSize: 13, color: skin.onSurface,
        letterSpacing: '0.02em',
      }}>
        <div>{statusBarContent || '09:41'}</div>
        <div style={{
          position: 'absolute', left: '50%', top: 8, transform: 'translateX(-50%)',
          width: 26, height: 26, borderRadius: '50%', background: '#000',
        }} />
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <Icon name="signal" size={14} strokeWidth={2} />
          <span style={{ fontSize: 12 }}>100%</span>
        </div>
      </div>
      {/* content */}
      <div style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {children}
      </div>
      {/* nav */}
      {navContent}
      {/* gesture bar */}
      <div style={{ height: 22, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, background: skin.navBg || skin.surface }}>
        <div style={{ width: 110, height: 4, borderRadius: 2, background: skin.onSurface, opacity: 0.35 }} />
      </div>
    </div>
  );
}

// Securtiy → color mapping (shared)
function securityTone(security, skin) {
  if (security === 'Open') return skin.danger;
  if (security === 'WEP')  return skin.danger;
  if (security.includes('WPA3')) return skin.success;
  return skin.warning;
}

Object.assign(window, {
  rssiPct, rssiBars, Icon, lanRoleIcon, btTypeIcon, PhoneShell, securityTone,
});
