// Variation A — SPECTRUM: instrument-panel, dark, monospaced, dense.

const skinA = {
  surface: '#07090a',
  surfaceRaised: '#0e1214',
  surfaceHi: '#131719',
  onSurface: '#e8efec',
  onSurfaceDim: '#7c8a86',
  onSurfaceFaint: '#3b4543',
  frameBorder: '#1c2225',
  bezel: '#111416',
  navBg: '#07090a',
  accent: '#c8ff4f',        // chartreuse — oscilloscope
  accentDim: '#5e7a20',
  accent2: '#6ed4ff',       // cyan trace
  success: '#7bd88f',
  warning: '#ffcb5e',
  danger: '#ff7a66',
  gridLine: '#1a2023',
  fontDisplay: '"JetBrains Mono", ui-monospace, monospace',
  fontBody: '"Inter", system-ui, sans-serif',
  fontMono: '"JetBrains Mono", ui-monospace, monospace',
};

// ─── shared UI bits ─────────────────────────────────────────

function AHeader({ title, subtitle, onRefresh, scanning, stats }) {
  return (
    <div style={{ padding: '12px 18px 10px', borderBottom: `1px solid ${skinA.gridLine}`, background: skinA.surface }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
            SCANNER / {title.toUpperCase()}
          </div>
          <div style={{ fontFamily: skinA.fontDisplay, fontSize: 26, fontWeight: 500, letterSpacing: '-0.02em', marginTop: 2 }}>
            {subtitle}
          </div>
        </div>
        <button onClick={onRefresh} style={{
          background: scanning ? skinA.accent : 'transparent',
          color: scanning ? '#07090a' : skinA.accent,
          border: `1px solid ${scanning ? skinA.accent : skinA.accentDim}`,
          borderRadius: 999, padding: '8px 14px', fontFamily: skinA.fontMono, fontSize: 11,
          letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: '50%',
            background: scanning ? '#07090a' : skinA.accent,
            animation: scanning ? 'blinkA 0.8s infinite' : 'none',
          }} />
          {scanning ? 'SCANNING' : 'SCAN'}
        </button>
      </div>
      {stats && (
        <div style={{ display: 'flex', gap: 18, marginTop: 12, fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim }}>
          {stats.map((s, i) => (
            <div key={i}>
              <span style={{ color: skinA.onSurface, fontSize: 14, letterSpacing: '0.02em' }}>{s.value}</span>
              <span style={{ marginLeft: 6 }}>{s.label}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Thin signal "trace" line (like an oscilloscope reading)
function SignalTrace({ rssi, width = 88, height = 20 }) {
  const pct = rssiPct(rssi);
  // build a tiny waveform shape based on rssi
  const amp = Math.max(1, Math.round(pct * 9));
  const path = [];
  const steps = 20;
  for (let i = 0; i <= steps; i++) {
    const x = (i / steps) * width;
    const y = height / 2 + Math.sin(i * 0.9 + rssi) * amp * 0.5;
    path.push(`${i === 0 ? 'M' : 'L'}${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      <path d={path.join(' ')} fill="none"
        stroke={pct > 0.6 ? skinA.accent : pct > 0.3 ? skinA.warning : skinA.danger}
        strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

// ─── WIFI ───────────────────────────────────────────────────

function AWifi({ scanning, setScanning, onOpenDetail }) {
  const [filter, setFilter] = React.useState('all');

  const networks = React.useMemo(() => {
    let n = [...WIFI_NETWORKS];
    if (filter === '2.4') n = n.filter(x => x.band === '2.4');
    if (filter === '5')   n = n.filter(x => x.band === '5');
    if (filter === 'risk') n = n.filter(x => ['Open','WEP'].includes(x.security) || x.wps);
    return n.sort((a, b) => b.rssi - a.rssi);
  }, [filter]);

  const counts = { all: WIFI_NETWORKS.length, '2.4': WIFI_NETWORKS.filter(x=>x.band==='2.4').length, '5': WIFI_NETWORKS.filter(x=>x.band==='5').length };

  return (
    <>
      <AHeader title="WIFI" subtitle="Airspace"
        onRefresh={() => setScanning(s => !s)} scanning={scanning}
        stats={[
          { value: WIFI_NETWORKS.length, label: 'found' },
          { value: WIFI_NETWORKS.filter(x=>x.band==='2.4').length, label: '2.4GHz' },
          { value: WIFI_NETWORKS.filter(x=>x.band==='5').length, label: '5GHz' },
          { value: 2, label: 'risks' },
        ]}
      />
      {/* filter chips */}
      <div style={{ display: 'flex', gap: 6, padding: '10px 18px', borderBottom: `1px solid ${skinA.gridLine}` }}>
        {[['all','ALL',counts.all],['2.4','2.4GHZ',counts['2.4']],['5','5GHZ',counts['5']],['risk','⚠ RISK',2]].map(([k,l,c]) => (
          <button key={k} onClick={() => setFilter(k)} style={{
            flex: 1, background: filter===k ? skinA.accent : 'transparent',
            color: filter===k ? '#07090a' : skinA.onSurfaceDim,
            border: `1px solid ${filter===k ? skinA.accent : skinA.gridLine}`,
            borderRadius: 6, padding: '6px 0', fontFamily: skinA.fontMono, fontSize: 10,
            letterSpacing: '0.1em', cursor: 'pointer',
          }}>{l} <span style={{ opacity: 0.6 }}>{c}</span></button>
        ))}
      </div>
      {/* list */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {networks.map((n) => {
          const risk = n.security === 'Open' || n.security === 'WEP' || n.wps;
          return (
            <div key={n.bssid} onClick={() => onOpenDetail(n)}
              style={{ borderBottom: `1px solid ${skinA.gridLine}`, cursor: 'pointer', background: n.connected ? 'rgba(200,255,79,0.04)' : 'transparent' }}>
              <div style={{ display: 'flex', alignItems: 'center', padding: '14px 18px', gap: 14 }}>
                {/* left: rssi numeric + trace */}
                <div style={{ width: 66, flexShrink: 0 }}>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 18, color: n.rssi > -60 ? skinA.accent : n.rssi > -75 ? skinA.warning : skinA.danger, letterSpacing: '-0.02em' }}>
                    {n.rssi}
                    <span style={{ fontSize: 10, color: skinA.onSurfaceDim, marginLeft: 2 }}>dBm</span>
                  </div>
                  <SignalTrace rssi={n.rssi} width={66} height={12} />
                </div>
                {/* middle: ssid + meta */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    {n.connected && <span style={{ width: 6, height: 6, borderRadius: '50%', background: skinA.accent }}/>}
                    <div style={{ fontSize: 15, fontWeight: 500, letterSpacing: '-0.01em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {n.ssid === '(hidden)' ? <span style={{ color: skinA.onSurfaceDim, fontStyle: 'italic' }}>{n.ssid}</span> : n.ssid}
                    </div>
                  </div>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 3, letterSpacing: '0.04em' }}>
                    {n.band}GHz · CH{n.channel} · {n.standard} · {n.vendor}
                  </div>
                </div>
                {/* right: security */}
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: risk ? skinA.danger : skinA.onSurfaceDim, letterSpacing: '0.1em' }}>
                    {risk ? '⚠' : '•'} {n.security}
                  </div>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceFaint, marginTop: 2 }}>
                    ~{n.distance.toFixed(1)}m
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ─── CHANNEL ANALYSIS ─────────────────────────────────────

function AChannel() {
  const [band, setBand] = React.useState('2.4');
  const data = band === '2.4' ? CHANNEL_2GHZ : CHANNEL_5GHZ;
  const maxUtil = Math.max(...data.map(d => d.util));
  const best = data.reduce((a, b) => a.util < b.util ? a : b);

  return (
    <>
      <AHeader title="SPECTRUM" subtitle="Channel Analysis" stats={[
        { value: 'CH'+best.ch, label: 'recommended' },
        { value: best.util+'%', label: 'utilization' },
        { value: data.length, label: 'channels' },
      ]}/>
      <div style={{ display: 'flex', gap: 6, padding: '10px 18px', borderBottom: `1px solid ${skinA.gridLine}` }}>
        {['2.4','5'].map(b => (
          <button key={b} onClick={() => setBand(b)} style={{
            flex: 1, background: band===b ? skinA.accent : 'transparent',
            color: band===b ? '#07090a' : skinA.onSurfaceDim,
            border: `1px solid ${band===b ? skinA.accent : skinA.gridLine}`,
            borderRadius: 6, padding: '8px 0', fontFamily: skinA.fontMono, fontSize: 11, letterSpacing: '0.14em', cursor: 'pointer',
          }}>{b} GHZ BAND</button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: 18 }}>
        {/* oscilloscope grid */}
        <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em', marginBottom: 10 }}>
          UTILIZATION // DB/CH
        </div>
        <div style={{
          background: skinA.surfaceRaised, border: `1px solid ${skinA.gridLine}`,
          borderRadius: 6, padding: '16px 14px 10px', position: 'relative',
          backgroundImage: `linear-gradient(${skinA.gridLine} 1px, transparent 1px), linear-gradient(90deg, ${skinA.gridLine} 1px, transparent 1px)`,
          backgroundSize: '100% 25%, 10% 100%',
        }}>
          {/* bars */}
          <div style={{ display: 'flex', alignItems: 'flex-end', height: 160, gap: 4 }}>
            {data.map(d => {
              const h = (d.util / 100) * 150;
              const tone = d.util > 70 ? skinA.danger : d.util > 40 ? skinA.warning : skinA.accent;
              return (
                <div key={d.ch} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 9, color: tone, marginBottom: 3 }}>{d.util}</div>
                  <div style={{ width: '100%', height: h, background: tone, opacity: 0.85, borderRadius: '2px 2px 0 0', position: 'relative' }}>
                    {d.count > 0 && (
                      <div style={{
                        position: 'absolute', top: -18, left: '50%', transform: 'translateX(-50%)',
                        width: 16, height: 16, borderRadius: '50%', background: skinA.surface,
                        border: `1px solid ${tone}`, color: tone, fontFamily: skinA.fontMono, fontSize: 9,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}>{d.count}</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {/* channel labels */}
          <div style={{ display: 'flex', gap: 4, marginTop: 8 }}>
            {data.map(d => (
              <div key={d.ch} style={{ flex: 1, textAlign: 'center', fontFamily: skinA.fontMono, fontSize: 10, color: d.ch === best.ch ? skinA.accent : skinA.onSurfaceDim }}>
                {d.ch}
              </div>
            ))}
          </div>
        </div>

        {/* recommendation card */}
        <div style={{
          marginTop: 20, border: `1px solid ${skinA.accentDim}`, borderRadius: 6,
          background: 'linear-gradient(180deg, rgba(200,255,79,0.08), transparent)',
          padding: 16,
        }}>
          <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.accent, letterSpacing: '0.2em' }}>RECOMMENDED</div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginTop: 6 }}>
            <div style={{ fontFamily: skinA.fontDisplay, fontSize: 56, fontWeight: 500, color: skinA.accent, letterSpacing: '-0.04em', lineHeight: 1 }}>
              {best.ch}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13 }}>Lowest utilization on band</div>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim, marginTop: 2 }}>
                {best.util}% occupied · {best.count} AP{best.count===1?'':'s'} · no overlap
              </div>
            </div>
          </div>
        </div>

        {/* legend */}
        <div style={{ display: 'flex', gap: 14, marginTop: 18, fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 10, height: 10, background: skinA.accent }}/> CLEAR
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 10, height: 10, background: skinA.warning }}/> MED
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 10, height: 10, background: skinA.danger }}/> CONGESTED
          </div>
        </div>
      </div>
    </>
  );
}

// ─── BLUETOOTH (radial radar) ──────────────────────────────

function ABluetooth({ onOpenGatt }) {
  const [selected, setSelected] = React.useState(null);

  // position devices on radar by rssi (distance) + hash(addr) angle
  const positioned = BT_DEVICES.map((d, i) => {
    const angle = (i * 137.5) % 360;
    const dist = 1 - rssiPct(d.rssi);
    return { ...d, angle, dist };
  });

  const sel = positioned.find(d => d.addr === selected);

  return (
    <>
      <AHeader title="BLUETOOTH" subtitle="Radar" stats={[
        { value: BT_DEVICES.length, label: 'devices' },
        { value: BT_DEVICES.filter(d=>d.bond==='BONDED').length, label: 'bonded' },
        { value: BT_DEVICES.filter(d=>d.type==='BLE').length, label: 'BLE' },
      ]}/>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {/* radar */}
        <div style={{ position: 'relative', width: '100%', aspectRatio: '1', padding: 18 }}>
          <div style={{
            position: 'absolute', inset: 18, borderRadius: '50%',
            border: `1px solid ${skinA.gridLine}`,
            background: `radial-gradient(circle at 50% 50%, ${skinA.surfaceRaised} 0%, ${skinA.surface} 70%)`,
          }}>
            {/* rings */}
            {[0.33, 0.66, 1].map((r, i) => (
              <div key={i} style={{
                position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
                width: `${r*100}%`, height: `${r*100}%`, borderRadius: '50%',
                border: `1px dashed ${skinA.gridLine}`,
              }}/>
            ))}
            {/* crosshair */}
            <div style={{ position: 'absolute', left: 0, right: 0, top: '50%', height: 1, background: skinA.gridLine }}/>
            <div style={{ position: 'absolute', top: 0, bottom: 0, left: '50%', width: 1, background: skinA.gridLine }}/>
            {/* sweep */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%',
              width: '50%', height: 1, transformOrigin: '0 50%',
              background: `linear-gradient(90deg, ${skinA.accent}, transparent)`,
              animation: 'sweep 4s linear infinite',
            }}/>
            {/* dots */}
            {positioned.map(d => {
              const x = 50 + Math.cos(d.angle * Math.PI/180) * d.dist * 42;
              const y = 50 + Math.sin(d.angle * Math.PI/180) * d.dist * 42;
              const isSel = selected === d.addr;
              return (
                <button key={d.addr} onClick={() => setSelected(d.addr)} style={{
                  position: 'absolute', left: `${x}%`, top: `${y}%`,
                  transform: 'translate(-50%,-50%)',
                  width: isSel ? 12 : 8, height: isSel ? 12 : 8, borderRadius: '50%',
                  background: d.bond === 'BONDED' ? skinA.accent : skinA.accent2,
                  boxShadow: isSel ? `0 0 0 3px ${skinA.accent}40` : `0 0 10px ${skinA.accent}80`,
                  border: 'none', cursor: 'pointer', padding: 0,
                }}/>
              );
            })}
            {/* center device */}
            <div style={{
              position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
              width: 10, height: 10, borderRadius: '50%',
              background: skinA.onSurface, border: `2px solid ${skinA.surface}`,
            }}/>
          </div>
        </div>

        {/* selected or list */}
        {sel ? (
          <div style={{ padding: 18, borderTop: `1px solid ${skinA.gridLine}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Icon name={btTypeIcon(sel.minorClass)} size={28} color={skinA.accent} strokeWidth={1.4} />
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: skinA.fontDisplay, fontSize: 20, letterSpacing: '-0.01em' }}>
                  {sel.name === '—' ? <span style={{ color: skinA.onSurfaceDim, fontStyle: 'italic' }}>{sel.vendor} device</span> : sel.name}
                </div>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim }}>
                  {sel.vendor} · {sel.minorClass} · {sel.type}
                </div>
              </div>
              <button onClick={() => setSelected(null)} style={{ background: 'transparent', border: `1px solid ${skinA.gridLine}`, color: skinA.onSurfaceDim, borderRadius: 4, width: 28, height: 28, cursor: 'pointer' }}>
                <Icon name="close" size={14} />
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px 18px', marginTop: 12, fontFamily: skinA.fontMono, fontSize: 11 }}>
              {[['ADDR',sel.addr],['RSSI',sel.rssi+' dBm'],['BOND',sel.bond],['TX',(sel.rssi+45)+' dBm']].map(([k,v],i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderBottom: `1px dashed ${skinA.gridLine}` }}>
                  <span style={{ color: skinA.onSurfaceDim }}>{k}</span><span>{v}</span>
                </div>
              ))}
            </div>
            <button onClick={onOpenGatt} style={{ marginTop: 14, width: '100%', background: skinA.accent, color: '#07090a', border: 'none', padding: '12px 0', fontFamily: skinA.fontMono, fontSize: 11, letterSpacing: '0.2em', borderRadius: 4, cursor: 'pointer' }}>
              EXPLORE GATT →
            </button>
          </div>
        ) : (
          <div style={{ padding: '6px 18px 18px', borderTop: `1px solid ${skinA.gridLine}` }}>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em', padding: '12px 0' }}>
              NEARBY · {BT_DEVICES.length}
            </div>
            {BT_DEVICES.slice().sort((a,b)=>b.rssi-a.rssi).map(d => (
              <button key={d.addr} onClick={() => setSelected(d.addr)} style={{
                display: 'flex', width: '100%', alignItems: 'center', gap: 12,
                padding: '10px 0', background: 'transparent', border: 'none', borderBottom: `1px solid ${skinA.gridLine}`, cursor: 'pointer', textAlign: 'left',
              }}>
                <Icon name={btTypeIcon(d.minorClass)} size={18} color={skinA.onSurfaceDim}/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, color: skinA.onSurface, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {d.name === '—' ? <span style={{ color: skinA.onSurfaceDim, fontStyle: 'italic' }}>{d.vendor}</span> : d.name}
                  </div>
                  <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim }}>{d.addr} · {d.type}</div>
                </div>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 13, color: d.rssi > -60 ? skinA.accent : d.rssi > -75 ? skinA.warning : skinA.danger }}>
                  {d.rssi}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </>
  );
}

// ─── LAN ────────────────────────────────────────────────────

function ALan() {
  return (
    <>
      <AHeader title="LAN" subtitle="Local Net" stats={[
        { value: LAN_DEVICES.length, label: 'hosts' },
        { value: LAN_DEVICES.reduce((a,b)=>a+b.ports.length,0), label: 'ports' },
        { value: '192.168.1.0/24', label: 'subnet' },
      ]}/>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {LAN_DEVICES.map((d, i) => (
          <div key={d.ip} style={{ display: 'flex', alignItems: 'center', padding: '14px 18px', borderBottom: `1px solid ${skinA.gridLine}`, gap: 14 }}>
            <div style={{ width: 32, height: 32, borderRadius: 4, border: `1px solid ${skinA.gridLine}`, background: skinA.surfaceRaised, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon name={lanRoleIcon(d.role)} size={16} color={skinA.accent}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 14, letterSpacing: '-0.01em' }}>{d.ip}</div>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {d.name} · {d.vendor}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
              {d.ports.slice(0, 4).map(p => (
                <div key={p} style={{
                  fontFamily: skinA.fontMono, fontSize: 9, padding: '3px 5px',
                  border: `1px solid ${p===22||p===23||p===80 ? skinA.warning : skinA.gridLine}`,
                  color: p===22||p===23||p===80 ? skinA.warning : skinA.onSurfaceDim,
                  borderRadius: 2, letterSpacing: '0.04em',
                }}>{p}</div>
              ))}
              {d.ports.length > 4 && <div style={{ fontFamily: skinA.fontMono, fontSize: 9, color: skinA.onSurfaceDim }}>+{d.ports.length-4}</div>}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── MONITOR ────────────────────────────────────────────────

function AMonitor({ liveData }) {
  const { rssi, gw, pub } = liveData;
  const curRssi = rssi[rssi.length-1];
  const curGw = gw[gw.length-1];
  const curPub = pub[pub.length-1];

  const makePath = (arr, max, min, w, h) => {
    return arr.map((v, i) => {
      const x = (i / (arr.length-1)) * w;
      const y = h - ((v - min) / (max - min)) * h;
      return `${i===0?'M':'L'}${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  };

  return (
    <>
      <AHeader title="MONITOR" subtitle="Live" stats={[
        { value: '5s', label: 'interval' },
        { value: rssi.length+'×', label: 'samples' },
        { value: 'FG', label: 'service' },
      ]}/>
      <div style={{ flex: 1, overflowY: 'auto', padding: 18, display: 'flex', flexDirection: 'column', gap: 16 }}>
        {[
          { label: 'SIGNAL', unit: 'dBm', cur: curRssi.toFixed(0), min: -65, max: -38, arr: rssi, color: skinA.accent, avg: (rssi.reduce((a,b)=>a+b,0)/rssi.length).toFixed(1) },
          { label: 'GATEWAY LATENCY', unit: 'ms', cur: curGw.toFixed(1), min: 0, max: 6, arr: gw, color: skinA.accent2, avg: (gw.reduce((a,b)=>a+b,0)/gw.length).toFixed(2) },
          { label: 'INTERNET (8.8.8.8)', unit: 'ms', cur: curPub.toFixed(0), min: 5, max: 32, arr: pub, color: skinA.warning, avg: (pub.reduce((a,b)=>a+b,0)/pub.length).toFixed(1) },
        ].map((m, i) => (
          <div key={i} style={{ background: skinA.surfaceRaised, border: `1px solid ${skinA.gridLine}`, borderRadius: 6, padding: 14 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>{m.label}</div>
              <div>
                <span style={{ fontFamily: skinA.fontDisplay, fontSize: 26, color: m.color, letterSpacing: '-0.02em' }}>{m.cur}</span>
                <span style={{ fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim, marginLeft: 4 }}>{m.unit}</span>
              </div>
            </div>
            <svg viewBox={`0 0 340 60`} style={{ width: '100%', height: 60, marginTop: 6, display: 'block' }} preserveAspectRatio="none">
              {[0,1,2,3].map(g => <line key={g} x1="0" x2="340" y1={g*15} y2={g*15} stroke={skinA.gridLine} strokeDasharray="2 3"/>)}
              <path d={makePath(m.arr, m.max, m.min, 340, 60)} fill="none" stroke={m.color} strokeWidth="1.4"/>
              <path d={makePath(m.arr, m.max, m.min, 340, 60) + ` L340 60 L0 60 Z`} fill={m.color} opacity="0.08"/>
            </svg>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 4 }}>
              <span>AVG {m.avg}{m.unit}</span>
              <span>n={m.arr.length}</span>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── SECURITY AUDIT ─────────────────────────────────────────

function ASecurity() {
  const grade = 'C';
  const severityColor = { CRIT: skinA.danger, HIGH: '#ff9b66', MED: skinA.warning, LOW: '#8ec5d9', INFO: skinA.onSurfaceDim };

  return (
    <>
      <AHeader title="AUDIT" subtitle="Security" stats={[
        { value: AUDIT_FINDINGS.length, label: 'findings' },
        { value: AUDIT_FINDINGS.filter(f=>f.severity==='CRIT'||f.severity==='HIGH').length, label: 'actionable' },
      ]}/>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: 22, display: 'flex', alignItems: 'center', gap: 18, borderBottom: `1px solid ${skinA.gridLine}` }}>
          <div style={{
            width: 96, height: 96, borderRadius: '50%',
            background: `conic-gradient(${skinA.warning} 0% 55%, ${skinA.gridLine} 55% 100%)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative',
          }}>
            <div style={{ width: 80, height: 80, borderRadius: '50%', background: skinA.surface, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: skinA.fontDisplay, fontSize: 46, color: skinA.warning, letterSpacing: '-0.04em' }}>
              {grade}
            </div>
          </div>
          <div>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>GRADE</div>
            <div style={{ fontFamily: skinA.fontDisplay, fontSize: 22 }}>Moderate exposure</div>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim, marginTop: 2 }}>2 critical · 2 high · 3 info</div>
          </div>
        </div>
        <div>
          {AUDIT_FINDINGS.map((f, i) => (
            <div key={i} style={{ display: 'flex', padding: '14px 18px', borderBottom: `1px solid ${skinA.gridLine}`, gap: 12 }}>
              <div style={{
                width: 54, flexShrink: 0, fontFamily: skinA.fontMono, fontSize: 10,
                color: severityColor[f.severity], letterSpacing: '0.12em',
                border: `1px solid ${severityColor[f.severity]}`, borderRadius: 2,
                padding: '3px 0', textAlign: 'center', height: 'fit-content',
              }}>{f.severity}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, color: skinA.onSurface }}>{f.title}</div>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 2 }}>
                  {f.target}
                </div>
                <div style={{ fontSize: 12, color: skinA.onSurfaceDim, marginTop: 4 }}>{f.note}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

// ─── NAV ────────────────────────────────────────────────────

function ANav({ tab, setTab }) {
  const tabs = [
    { k: 'wifi', icon: 'wifi', label: 'WIFI' },
    { k: 'channel', icon: 'chart', label: 'CH' },
    { k: 'bt', icon: 'bt', label: 'BT' },
    { k: 'lan', icon: 'lan', label: 'LAN' },
    { k: 'monitor', icon: 'monitor', label: 'MON' },
    { k: 'sec', icon: 'shield', label: 'SEC' },
    { k: 'map', icon: 'map', label: 'MAP' },
    { k: 'inv', icon: 'inventory', label: 'INV' },
  ];
  return (
    <div style={{ background: skinA.surface, borderTop: `1px solid ${skinA.gridLine}`, display: 'flex' }}>
      {tabs.map(t => (
        <button key={t.k} onClick={() => setTab(t.k)} style={{
          flex: 1, background: 'transparent', border: 'none', padding: '10px 0 10px',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
          cursor: 'pointer', position: 'relative',
          color: tab===t.k ? skinA.accent : skinA.onSurfaceDim,
        }}>
          {tab===t.k && <div style={{ position: 'absolute', top: 0, left: '25%', right: '25%', height: 2, background: skinA.accent }}/>}
          <Icon name={t.icon} size={16} strokeWidth={1.5}/>
          <span style={{ fontFamily: skinA.fontMono, fontSize: 8, letterSpacing: '0.1em' }}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}

// ─── ROOT ───────────────────────────────────────────────────

function VariantA({ startAt }) {
  const [tab, setTab] = React.useState('wifi');
  const [scanning, setScanning] = React.useState(false);
  const [liveData, setLiveData] = React.useState(() => genMonitorData());
  const [route, setRoute] = React.useState(startAt || 'main'); // 'onboard' | 'main' | 'wifi-detail' | 'gatt' | 'export'
  const [wifiDetail, setWifiDetail] = React.useState(null);

  React.useEffect(() => {
    const t = setInterval(() => {
      setLiveData(d => ({
        rssi: [...d.rssi.slice(1), Math.max(-65, Math.min(-38, d.rssi[d.rssi.length-1] + (Math.random()-0.5)*2))],
        gw:   [...d.gw.slice(1),   Math.max(0.8, Math.min(5.5, d.gw[d.gw.length-1] + (Math.random()-0.5)*0.6))],
        pub:  [...d.pub.slice(1),  Math.max(8, Math.min(28, d.pub[d.pub.length-1] + (Math.random()-0.5)*3))],
      }));
    }, 1200);
    return () => clearInterval(t);
  }, []);

  if (route === 'onboard') {
    return (
      <PhoneShell skin={skinA}
        statusBarContent={<span style={{ color: skinA.accent, letterSpacing: '0.12em' }}>09:41:22</span>}
        navContent={null}>
        <AOnboarding onDone={() => setRoute('main')}/>
      </PhoneShell>
    );
  }

  if (route === 'wifi-detail' && wifiDetail) {
    return (
      <PhoneShell skin={skinA}
        statusBarContent={<span style={{ color: skinA.accent, letterSpacing: '0.12em' }}>● LIVE  09:41:22</span>}
        navContent={<ANav tab={tab} setTab={(t) => { setRoute('main'); setTab(t); }}/>}>
        <AWifiDetail network={wifiDetail} onClose={() => setRoute('main')}/>
      </PhoneShell>
    );
  }

  if (route === 'gatt') {
    return (
      <PhoneShell skin={skinA}
        statusBarContent={<span style={{ color: skinA.accent, letterSpacing: '0.12em' }}>● LIVE  09:41:22</span>}
        navContent={<ANav tab={tab} setTab={(t) => { setRoute('main'); setTab(t); }}/>}>
        <AGatt onBack={() => setRoute('main')}/>
      </PhoneShell>
    );
  }

  return (
    <PhoneShell skin={skinA}
      statusBarContent={<span style={{ color: skinA.accent, letterSpacing: '0.12em' }}>● LIVE  09:41:22</span>}
      navContent={<ANav tab={tab} setTab={setTab}/>}>
      {tab === 'wifi' && <AWifi scanning={scanning} setScanning={setScanning} onOpenDetail={(n) => { setWifiDetail(n); setRoute('wifi-detail'); }}/>}
      {tab === 'channel' && <AChannel/>}
      {tab === 'bt' && <ABluetooth onOpenGatt={() => setRoute('gatt')}/>}
      {tab === 'lan' && <ALan/>}
      {tab === 'monitor' && <AMonitor liveData={liveData}/>}
      {tab === 'sec' && <ASecurity/>}
      {tab === 'map' && <AMap/>}
      {tab === 'inv' && <AInventory onOpenExport={() => setRoute('export')}/>}
      {route === 'export' && <AExport onClose={() => setRoute('main')}/>}
    </PhoneShell>
  );
}

Object.assign(window, { VariantA, skinA });
