// Variation B — FIELD NOTES: calm minimal, light, document-like.

const skinB = {
  surface: '#f7f4ee',
  surfaceRaised: '#fefcf7',
  surfaceInk: '#1a1815',
  onSurface: '#1a1815',
  onSurfaceDim: '#706a5e',
  onSurfaceFaint: '#b5ad9e',
  divider: '#e4ddd0',
  frameBorder: '#1a1815',
  bezel: '#2a2622',
  navBg: '#f0ebe0',
  accent: '#c04a2b',        // rust
  accent2: '#3d5a4a',       // forest
  success: '#3d5a4a',
  warning: '#b8923a',
  danger: '#c04a2b',
  fontDisplay: '"Fraunces", "Canela", Georgia, serif',
  fontBody: '"Inter", system-ui, sans-serif',
  fontMono: '"JetBrains Mono", ui-monospace, monospace',
};

function BHeader({ eyebrow, title, subtitle, right }) {
  return (
    <div style={{ padding: '18px 22px 14px', borderBottom: `1px solid ${skinB.divider}`, background: skinB.surface }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.24em', textTransform: 'uppercase' }}>
            {eyebrow}
          </div>
          <div style={{ fontFamily: skinB.fontDisplay, fontSize: 34, fontWeight: 400, letterSpacing: '-0.02em', lineHeight: 1.05, marginTop: 4 }}>
            {title}
          </div>
          {subtitle && (
            <div style={{ fontSize: 13, color: skinB.onSurfaceDim, marginTop: 4, fontStyle: 'italic' }}>
              {subtitle}
            </div>
          )}
        </div>
        {right}
      </div>
    </div>
  );
}

function BScanButton({ scanning, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: scanning ? skinB.accent : skinB.surfaceInk, color: skinB.surfaceRaised,
      border: 'none', borderRadius: 999, padding: '10px 18px',
      fontFamily: skinB.fontBody, fontSize: 12, fontWeight: 500,
      letterSpacing: '0.08em', textTransform: 'uppercase', cursor: 'pointer',
      display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: scanning ? '#fff' : skinB.accent, animation: scanning ? 'blinkA 0.8s infinite' : 'none' }}/>
      {scanning ? 'Scanning' : 'Scan'}
    </button>
  );
}

// Horizon bar — a single thin filled capsule scaled by rssi
function HorizonBar({ rssi, color }) {
  const pct = rssiPct(rssi);
  return (
    <div style={{ width: '100%', height: 3, background: skinB.divider, borderRadius: 2, overflow: 'hidden' }}>
      <div style={{ width: `${pct*100}%`, height: '100%', background: color || skinB.surfaceInk }}/>
    </div>
  );
}

function BWifi({ scanning, setScanning }) {
  const [expanded, setExpanded] = React.useState(null);
  const sorted = [...WIFI_NETWORKS].sort((a,b) => b.rssi - a.rssi);
  const connected = sorted.find(n => n.connected);
  const others = sorted.filter(n => !n.connected);

  return (
    <>
      <BHeader eyebrow="Tab 01 / Wireless"
        title="Networks"
        subtitle={`${WIFI_NETWORKS.length} in range — scanned just now`}
        right={<BScanButton scanning={scanning} onClick={() => setScanning(s => !s)}/>}
      />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {connected && (
          <div style={{ padding: '14px 22px', background: skinB.surfaceRaised, borderBottom: `1px solid ${skinB.divider}` }}>
            <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.accent, letterSpacing: '0.2em' }}>• CONNECTED</div>
            <div style={{ fontFamily: skinB.fontDisplay, fontSize: 22, marginTop: 4 }}>{connected.ssid}</div>
            <div style={{ display: 'flex', gap: 18, marginTop: 8, fontSize: 12, color: skinB.onSurfaceDim }}>
              <div><span style={{ color: skinB.onSurface, fontFamily: skinB.fontMono }}>{connected.rssi}</span> dBm</div>
              <div>Ch <span style={{ color: skinB.onSurface }}>{connected.channel}</span></div>
              <div>{connected.band} GHz</div>
              <div>{connected.standard}</div>
            </div>
          </div>
        )}
        <div style={{ padding: '18px 22px 8px', fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.2em' }}>
          IN RANGE — SORTED BY SIGNAL
        </div>
        {others.map(n => {
          const isOpen = expanded === n.bssid;
          const risk = n.security === 'Open' || n.security === 'WEP' || n.wps;
          return (
            <div key={n.bssid} onClick={() => setExpanded(isOpen ? null : n.bssid)}
              style={{ padding: '14px 22px', borderBottom: `1px solid ${skinB.divider}`, cursor: 'pointer' }}>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: skinB.fontDisplay, fontSize: 17, letterSpacing: '-0.01em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {n.ssid === '(hidden)' ? <span style={{ color: skinB.onSurfaceDim, fontStyle: 'italic' }}>hidden network</span> : n.ssid}
                  </div>
                  <div style={{ fontSize: 11, color: skinB.onSurfaceDim, marginTop: 3 }}>
                    {n.band} GHz · Ch {n.channel} · {n.security}{risk ? ' · ⚠ at risk' : ''} · {n.vendor}
                  </div>
                  <div style={{ marginTop: 8 }}>
                    <HorizonBar rssi={n.rssi} color={risk ? skinB.accent : skinB.onSurface}/>
                  </div>
                </div>
                <div style={{ textAlign: 'right', fontFamily: skinB.fontMono, minWidth: 54 }}>
                  <div style={{ fontSize: 16, color: skinB.onSurface }}>{n.rssi}</div>
                  <div style={{ fontSize: 10, color: skinB.onSurfaceDim, marginTop: 2 }}>{n.distance.toFixed(0)}m</div>
                </div>
              </div>
              {isOpen && (
                <div style={{ marginTop: 14, paddingTop: 14, borderTop: `1px dashed ${skinB.divider}`, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px 18px', fontSize: 12 }}>
                  {[['BSSID',n.bssid],['Frequency',n.freq+' MHz'],['Width',n.width+' MHz'],['Standard',n.standard],['WPS',n.wps?'Enabled':'Off'],['Vendor',n.vendor]].map(([k,v],i) => (
                    <div key={i}>
                      <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.12em' }}>{k.toUpperCase()}</div>
                      <div style={{ fontFamily: skinB.fontMono, fontSize: 12, marginTop: 2 }}>{v}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}

function BChannel() {
  const [band, setBand] = React.useState('2.4');
  const data = band==='2.4' ? CHANNEL_2GHZ : CHANNEL_5GHZ;
  const best = data.reduce((a,b) => a.util < b.util ? a : b);

  return (
    <>
      <BHeader eyebrow="Tab 02 / Spectrum"
        title="Channel map"
        subtitle={`Best guess: channel ${best.ch} — ${best.util}% busy`}
      />
      <div style={{ display: 'flex', gap: 8, padding: '12px 22px', borderBottom: `1px solid ${skinB.divider}` }}>
        {['2.4','5'].map(b => (
          <button key={b} onClick={() => setBand(b)} style={{
            flex: 1, background: band===b ? skinB.surfaceInk : 'transparent',
            color: band===b ? skinB.surface : skinB.onSurface,
            border: `1px solid ${skinB.divider}`, borderRadius: 999, padding: '8px 0',
            fontSize: 12, fontWeight: 500, cursor: 'pointer',
          }}>{b} GHz</button>
        ))}
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: 22 }}>
        <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.2em', marginBottom: 16 }}>
          UTILIZATION BY CHANNEL
        </div>
        {data.map(d => (
          <div key={d.ch} style={{ padding: '9px 0', borderBottom: `1px solid ${skinB.divider}`, display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ fontFamily: skinB.fontDisplay, fontSize: 20, width: 36, textAlign: 'right', color: d.ch===best.ch ? skinB.accent : skinB.onSurface }}>
              {d.ch}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ height: 6, background: skinB.divider, borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  width: `${d.util}%`, height: '100%',
                  background: d.util > 70 ? skinB.accent : d.util > 40 ? skinB.warning : skinB.accent2,
                }}/>
              </div>
              <div style={{ fontSize: 11, color: skinB.onSurfaceDim, marginTop: 4 }}>
                {d.count > 0 ? `${d.count} network${d.count>1?'s':''}` : 'empty'}
              </div>
            </div>
            <div style={{ fontFamily: skinB.fontMono, fontSize: 12, color: skinB.onSurfaceDim, width: 36, textAlign: 'right' }}>{d.util}%</div>
          </div>
        ))}
        <div style={{ marginTop: 24, padding: 18, background: skinB.surfaceRaised, border: `1px solid ${skinB.divider}`, borderRadius: 6 }}>
          <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.accent, letterSpacing: '0.2em' }}>RECOMMENDATION</div>
          <div style={{ fontFamily: skinB.fontDisplay, fontSize: 24, marginTop: 4 }}>
            Move to <span style={{ color: skinB.accent }}>channel {best.ch}</span>.
          </div>
          <div style={{ fontSize: 13, color: skinB.onSurfaceDim, marginTop: 6, lineHeight: 1.45 }}>
            Lowest utilization on the {band} GHz band with no overlap from neighbouring access points.
          </div>
        </div>
      </div>
    </>
  );
}

function BBluetooth() {
  const [tab, setTab] = React.useState('all');
  const filtered = tab === 'all' ? BT_DEVICES : tab === 'bonded' ? BT_DEVICES.filter(d => d.bond === 'BONDED') : BT_DEVICES.filter(d => d.type === 'BLE');
  const sorted = [...filtered].sort((a,b) => b.rssi - a.rssi);

  return (
    <>
      <BHeader eyebrow="Tab 03 / Bluetooth"
        title="Devices nearby"
        subtitle={`${BT_DEVICES.length} picked up — ${BT_DEVICES.filter(d=>d.bond==='BONDED').length} paired`}
      />
      <div style={{ display: 'flex', gap: 8, padding: '12px 22px', borderBottom: `1px solid ${skinB.divider}` }}>
        {[['all','All',BT_DEVICES.length],['bonded','Paired',BT_DEVICES.filter(d=>d.bond==='BONDED').length],['ble','BLE only',BT_DEVICES.filter(d=>d.type==='BLE').length]].map(([k,l,c]) => (
          <button key={k} onClick={() => setTab(k)} style={{
            background: tab===k ? skinB.surfaceInk : 'transparent',
            color: tab===k ? skinB.surface : skinB.onSurface,
            border: `1px solid ${skinB.divider}`, borderRadius: 999, padding: '6px 14px',
            fontSize: 12, fontWeight: 500, cursor: 'pointer',
          }}>{l} <span style={{ opacity: 0.6 }}>{c}</span></button>
        ))}
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {sorted.map(d => (
          <div key={d.addr} style={{ display: 'flex', gap: 14, padding: '16px 22px', borderBottom: `1px solid ${skinB.divider}`, alignItems: 'center' }}>
            <div style={{
              width: 44, height: 44, borderRadius: '50%', background: skinB.surfaceRaised,
              border: `1px solid ${skinB.divider}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Icon name={btTypeIcon(d.minorClass)} size={20} color={skinB.surfaceInk} strokeWidth={1.4}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ fontFamily: skinB.fontDisplay, fontSize: 17, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {d.name === '—' ? <span style={{ color: skinB.onSurfaceDim, fontStyle: 'italic' }}>{d.vendor} device</span> : d.name}
                </div>
                {d.bond === 'BONDED' && <span style={{ fontSize: 10, fontFamily: skinB.fontMono, color: skinB.accent, letterSpacing: '0.12em' }}>• PAIRED</span>}
              </div>
              <div style={{ fontSize: 11, color: skinB.onSurfaceDim, marginTop: 2, fontFamily: skinB.fontMono }}>
                {d.addr} · {d.type} · {d.vendor}
              </div>
              <div style={{ marginTop: 8, width: 100 }}>
                <HorizonBar rssi={d.rssi}/>
              </div>
            </div>
            <div style={{ textAlign: 'right', fontFamily: skinB.fontMono }}>
              <div style={{ fontSize: 15 }}>{d.rssi}</div>
              <div style={{ fontSize: 10, color: skinB.onSurfaceDim }}>dBm</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function BLan() {
  const grouped = LAN_DEVICES.reduce((acc, d) => {
    (acc[d.role] = acc[d.role] || []).push(d);
    return acc;
  }, {});
  return (
    <>
      <BHeader eyebrow="Tab 04 / Local area"
        title="Your network"
        subtitle={`${LAN_DEVICES.length} hosts on 192.168.1.0/24`}
      />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {Object.entries(grouped).map(([role, devs]) => (
          <div key={role}>
            <div style={{ padding: '16px 22px 6px', fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.2em' }}>
              {role.toUpperCase()} · {devs.length}
            </div>
            {devs.map(d => (
              <div key={d.ip} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 22px', borderBottom: `1px solid ${skinB.divider}` }}>
                <Icon name={lanRoleIcon(d.role)} size={22} color={skinB.surfaceInk} strokeWidth={1.4}/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: skinB.fontDisplay, fontSize: 16 }}>{d.name}</div>
                  <div style={{ fontFamily: skinB.fontMono, fontSize: 11, color: skinB.onSurfaceDim }}>{d.ip} · {d.vendor}</div>
                </div>
                <div style={{ display: 'flex', gap: 4 }}>
                  {d.ports.slice(0, 3).map(p => (
                    <span key={p} style={{
                      fontFamily: skinB.fontMono, fontSize: 10, padding: '2px 6px',
                      background: p===22||p===23||p===80 ? skinB.accent+'15' : skinB.divider,
                      color: p===22||p===23||p===80 ? skinB.accent : skinB.onSurface,
                      borderRadius: 3,
                    }}>{p}</span>
                  ))}
                  {d.ports.length > 3 && <span style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, padding: '2px 2px' }}>+{d.ports.length-3}</span>}
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}

function BMonitor({ liveData }) {
  const { rssi, gw, pub } = liveData;
  const curRssi = rssi[rssi.length-1];
  const curGw = gw[gw.length-1];
  const curPub = pub[pub.length-1];

  const makePath = (arr, max, min, w, h) => {
    return arr.map((v, i) => {
      const x = (i / (arr.length-1)) * w;
      const y = h - ((v - min) / (max - min)) * h;
      return `${i===0?'M':'L'}${x.toFixed(1)} ${y.toFixed(1)}`;
    }).join(' ');
  };

  const metrics = [
    { label: 'Signal strength', cur: curRssi.toFixed(0), unit: 'dBm', min: -65, max: -38, arr: rssi, color: skinB.accent2 },
    { label: 'Gateway ping', cur: curGw.toFixed(1), unit: 'ms', min: 0, max: 6, arr: gw, color: skinB.accent },
    { label: 'Internet (8.8.8.8)', cur: curPub.toFixed(0), unit: 'ms', min: 5, max: 32, arr: pub, color: skinB.warning },
  ];

  return (
    <>
      <BHeader eyebrow="Tab 05 / Monitor"
        title="Quiet vigil"
        subtitle="Sampling every 5 seconds in the background"
      />
      <div style={{ flex: 1, overflowY: 'auto', padding: '22px 22px 28px' }}>
        {metrics.map((m, i) => (
          <div key={i} style={{ marginBottom: 24, paddingBottom: 24, borderBottom: i < metrics.length-1 ? `1px solid ${skinB.divider}` : 'none' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <div style={{ fontFamily: skinB.fontMono, fontSize: 10, color: skinB.onSurfaceDim, letterSpacing: '0.2em' }}>
                {m.label.toUpperCase()}
              </div>
              <div>
                <span style={{ fontFamily: skinB.fontDisplay, fontSize: 32, color: m.color, letterSpacing: '-0.02em' }}>{m.cur}</span>
                <span style={{ fontSize: 13, color: skinB.onSurfaceDim, marginLeft: 4 }}>{m.unit}</span>
              </div>
            </div>
            <svg viewBox="0 0 340 70" style={{ width: '100%', height: 70, marginTop: 10 }} preserveAspectRatio="none">
              <path d={makePath(m.arr, m.max, m.min, 340, 70) + ' L340 70 L0 70 Z'} fill={m.color} opacity="0.1"/>
              <path d={makePath(m.arr, m.max, m.min, 340, 70)} fill="none" stroke={m.color} strokeWidth="1.5" strokeLinejoin="round"/>
            </svg>
            <div style={{ fontSize: 11, color: skinB.onSurfaceDim, marginTop: 4, fontStyle: 'italic' }}>
              Last {m.arr.length} samples · stable
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function BSecurity() {
  const grade = 'C';
  const sevColor = { CRIT: skinB.accent, HIGH: '#d97a3a', MED: skinB.warning, LOW: skinB.accent2, INFO: skinB.onSurfaceDim };
  return (
    <>
      <BHeader eyebrow="Tab 06 / Audit"
        title="Security review"
        subtitle="A reading of your environment, freshly taken"
      />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '30px 22px', borderBottom: `1px solid ${skinB.divider}`, textAlign: 'center' }}>
          <div style={{ fontFamily: skinB.fontDisplay, fontSize: 120, fontWeight: 300, color: skinB.warning, lineHeight: 1, letterSpacing: '-0.04em' }}>{grade}</div>
          <div style={{ fontFamily: skinB.fontBody, fontSize: 14, color: skinB.onSurfaceDim, marginTop: -4 }}>
            Moderate — a few things worth fixing
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 18, marginTop: 16, fontFamily: skinB.fontMono, fontSize: 11 }}>
            <div><span style={{ color: skinB.accent }}>●</span> 2 critical</div>
            <div><span style={{ color: '#d97a3a' }}>●</span> 2 high</div>
            <div><span style={{ color: skinB.warning }}>●</span> 1 medium</div>
            <div><span style={{ color: skinB.onSurfaceDim }}>●</span> 2 info</div>
          </div>
        </div>
        {AUDIT_FINDINGS.map((f, i) => (
          <div key={i} style={{ padding: '16px 22px', borderBottom: `1px solid ${skinB.divider}`, display: 'flex', gap: 14 }}>
            <div style={{ width: 3, borderRadius: 2, background: sevColor[f.severity], flexShrink: 0 }}/>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, flexWrap: 'wrap' }}>
                <span style={{ fontFamily: skinB.fontMono, fontSize: 10, color: sevColor[f.severity], letterSpacing: '0.18em' }}>{f.severity}</span>
                <span style={{ fontFamily: skinB.fontDisplay, fontSize: 16 }}>{f.title}</span>
              </div>
              <div style={{ fontFamily: skinB.fontMono, fontSize: 11, color: skinB.onSurfaceDim, marginTop: 3 }}>{f.target}</div>
              <div style={{ fontSize: 13, color: skinB.onSurfaceDim, marginTop: 4, lineHeight: 1.45 }}>{f.note}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

function BNav({ tab, setTab }) {
  const tabs = [
    { k: 'wifi', icon: 'wifi', label: 'Wifi' },
    { k: 'channel', icon: 'chart', label: 'Ch' },
    { k: 'bt', icon: 'bt', label: 'Bt' },
    { k: 'lan', icon: 'lan', label: 'Lan' },
    { k: 'monitor', icon: 'monitor', label: 'Mon' },
    { k: 'sec', icon: 'shield', label: 'Sec' },
  ];
  return (
    <div style={{ background: skinB.navBg, borderTop: `1px solid ${skinB.divider}`, display: 'flex', padding: '4px 0' }}>
      {tabs.map(t => (
        <button key={t.k} onClick={() => setTab(t.k)} style={{
          flex: 1, background: 'transparent', border: 'none', padding: '8px 0',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, cursor: 'pointer',
          color: tab===t.k ? skinB.accent : skinB.onSurface,
        }}>
          <Icon name={t.icon} size={20} strokeWidth={tab===t.k ? 2 : 1.4}/>
          <span style={{ fontSize: 10, fontFamily: skinB.fontMono, letterSpacing: '0.1em' }}>{t.label}</span>
        </button>
      ))}
    </div>
  );
}

function VariantB() {
  const [tab, setTab] = React.useState('wifi');
  const [scanning, setScanning] = React.useState(false);
  const [liveData, setLiveData] = React.useState(() => genMonitorData());

  React.useEffect(() => {
    const t = setInterval(() => {
      setLiveData(d => ({
        rssi: [...d.rssi.slice(1), Math.max(-65, Math.min(-38, d.rssi[d.rssi.length-1] + (Math.random()-0.5)*2))],
        gw:   [...d.gw.slice(1),   Math.max(0.8, Math.min(5.5, d.gw[d.gw.length-1] + (Math.random()-0.5)*0.6))],
        pub:  [...d.pub.slice(1),  Math.max(8, Math.min(28, d.pub[d.pub.length-1] + (Math.random()-0.5)*3))],
      }));
    }, 1200);
    return () => clearInterval(t);
  }, []);

  return (
    <PhoneShell skin={skinB}
      statusBarContent={<span>09:41</span>}
      navContent={<BNav tab={tab} setTab={setTab}/>}>
      {tab === 'wifi' && <BWifi scanning={scanning} setScanning={setScanning}/>}
      {tab === 'channel' && <BChannel/>}
      {tab === 'bt' && <BBluetooth/>}
      {tab === 'lan' && <BLan/>}
      {tab === 'monitor' && <BMonitor liveData={liveData}/>}
      {tab === 'sec' && <BSecurity/>}
    </PhoneShell>
  );
}

Object.assign(window, { VariantB, skinB });
