// Variation A — additional screens: Inventory, BLE GATT, Map, Export, Onboarding, WiFi detail.
// Depends on skinA, Icon, PhoneShell, mock data.

// ─── WIFI DETAIL (full screen, replaces inline expand) ───────

function AWifiDetail({ network, onClose }) {
  const n = network;
  const risk = n.security === 'Open' || n.security === 'WEP' || n.wps;

  return (
    <>
      <div style={{ padding: '12px 18px', borderBottom: `1px solid ${skinA.gridLine}`, display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={onClose} style={{ background: 'transparent', border: `1px solid ${skinA.gridLine}`, color: skinA.onSurface, borderRadius: 4, width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="close" size={14}/>
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>WIFI / DETAIL</div>
        </div>
        <button style={{ background: 'transparent', border: `1px solid ${skinA.gridLine}`, color: skinA.onSurface, borderRadius: 4, width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="star" size={14}/>
        </button>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {/* hero */}
        <div style={{ padding: 22, borderBottom: `1px solid ${skinA.gridLine}` }}>
          <div style={{ fontFamily: skinA.fontDisplay, fontSize: 24, letterSpacing: '-0.02em' }}>
            {n.ssid === '(hidden)' ? <span style={{ color: skinA.onSurfaceDim, fontStyle: 'italic' }}>hidden network</span> : n.ssid}
            {n.connected && <span style={{ marginLeft: 10, fontSize: 11, fontFamily: skinA.fontMono, color: skinA.accent, letterSpacing: '0.14em' }}>● CONNECTED</span>}
          </div>
          <div style={{ display: 'flex', gap: 20, marginTop: 14, alignItems: 'flex-end' }}>
            <div>
              <div style={{ fontFamily: skinA.fontDisplay, fontSize: 56, lineHeight: 1, color: n.rssi > -60 ? skinA.accent : n.rssi > -75 ? skinA.warning : skinA.danger, letterSpacing: '-0.04em' }}>
                {n.rssi}
              </div>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.2em', marginTop: 2 }}>dBm · SIGNAL</div>
            </div>
            <div style={{ flex: 1 }}>
              <svg viewBox="0 0 300 80" style={{ width: '100%', height: 70 }} preserveAspectRatio="none">
                {[0,1,2,3].map(g => <line key={g} x1="0" x2="300" y1={g*20} y2={g*20} stroke={skinA.gridLine} strokeDasharray="2 3"/>)}
                <path d={Array.from({length:30},(_,i) => {
                  const x = (i/29)*300;
                  const y = 40 + Math.sin(i*0.5 + n.rssi*0.1) * 12 + Math.cos(i*0.3) * 8;
                  return `${i===0?'M':'L'}${x.toFixed(1)} ${y.toFixed(1)}`;
                }).join(' ')} fill="none" stroke={skinA.accent} strokeWidth="1.2"/>
              </svg>
            </div>
          </div>
        </div>
        {/* grid of specs */}
        <div style={{ padding: 18 }}>
          <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.2em', marginBottom: 10 }}>SPECIFICATIONS</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1, background: skinA.gridLine, border: `1px solid ${skinA.gridLine}` }}>
            {[
              ['BSSID',n.bssid],['CHANNEL',`${n.channel} (${n.band}GHz)`],
              ['FREQUENCY',`${n.freq} MHz`],['WIDTH',`${n.width} MHz`],
              ['STANDARD',n.standard],['VENDOR',n.vendor],
              ['SECURITY',n.security],['WPS',n.wps?'⚠ ENABLED':'OFF'],
              ['DISTANCE',`~${n.distance.toFixed(1)}m`],['CAPS',n.security.replace('-',' ')],
            ].map(([k,v],i) => (
              <div key={i} style={{ background: skinA.surface, padding: '12px 14px' }}>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 9, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>{k}</div>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 13, color: skinA.onSurface, marginTop: 3 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
        {risk && (
          <div style={{ margin: '0 18px 18px', padding: 14, border: `1px solid ${skinA.danger}`, background: 'rgba(255,122,102,0.06)', borderRadius: 4 }}>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.danger, letterSpacing: '0.2em' }}>⚠ RISK FLAG</div>
            <div style={{ fontSize: 13, color: skinA.onSurface, marginTop: 4 }}>
              {n.security === 'Open' && 'Open network — no encryption. Anyone can read traffic in transit.'}
              {n.security === 'WEP'  && 'WEP encryption is broken — can be cracked in minutes with airodump.'}
              {n.wps && n.security !== 'Open' && n.security !== 'WEP' && 'WPS is enabled — vulnerable to Pixie-Dust attack.'}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

// ─── INVENTORY ────────────────────────────────────────────

function AInventory({ onOpenExport }) {
  const [q, setQ] = React.useState('');
  const [kind, setKind] = React.useState('all');
  const [favOnly, setFavOnly] = React.useState(false);

  const filtered = INVENTORY.filter(x => {
    if (kind !== 'all' && x.kind !== kind) return false;
    if (favOnly && !x.fav) return false;
    if (q) {
      const hay = (x.name + ' ' + x.label + ' ' + x.id + ' ' + x.meta).toLowerCase();
      if (!hay.includes(q.toLowerCase())) return false;
    }
    return true;
  });

  return (
    <>
      <div style={{ padding: '12px 18px 10px', borderBottom: `1px solid ${skinA.gridLine}`, background: skinA.surface }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>SCANNER / INVENTORY</div>
            <div style={{ fontFamily: skinA.fontDisplay, fontSize: 26, fontWeight: 500, letterSpacing: '-0.02em', marginTop: 2 }}>Catalog</div>
          </div>
          <button onClick={onOpenExport} style={{
            background: 'transparent', color: skinA.accent, border: `1px solid ${skinA.accentDim}`,
            borderRadius: 999, padding: '8px 14px', fontFamily: skinA.fontMono, fontSize: 11,
            letterSpacing: '0.12em', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <Icon name="download" size={14}/>EXPORT
          </button>
        </div>
        {/* search */}
        <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 10, background: skinA.surfaceRaised, border: `1px solid ${skinA.gridLine}`, borderRadius: 4, padding: '8px 12px' }}>
          <Icon name="search" size={14} color={skinA.onSurfaceDim}/>
          <input
            value={q} onChange={e => setQ(e.target.value)}
            placeholder="search · name · mac · label"
            style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', color: skinA.onSurface, fontFamily: skinA.fontMono, fontSize: 12 }}
          />
          {q && <button onClick={() => setQ('')} style={{ background: 'transparent', border: 'none', color: skinA.onSurfaceDim, cursor: 'pointer' }}><Icon name="close" size={12}/></button>}
        </div>
      </div>
      {/* filters */}
      <div style={{ display: 'flex', gap: 6, padding: '10px 18px', borderBottom: `1px solid ${skinA.gridLine}`, overflowX: 'auto' }}>
        {[['all','ALL',INVENTORY.length],['wifi','WIFI',INVENTORY.filter(x=>x.kind==='wifi').length],['bt','BT',INVENTORY.filter(x=>x.kind==='bt').length],['lan','LAN',INVENTORY.filter(x=>x.kind==='lan').length]].map(([k,l,c]) => (
          <button key={k} onClick={() => setKind(k)} style={{
            background: kind===k ? skinA.accent : 'transparent',
            color: kind===k ? '#07090a' : skinA.onSurfaceDim,
            border: `1px solid ${kind===k ? skinA.accent : skinA.gridLine}`,
            borderRadius: 6, padding: '6px 12px', fontFamily: skinA.fontMono, fontSize: 10, letterSpacing: '0.1em', cursor: 'pointer', flexShrink: 0,
          }}>{l} <span style={{ opacity: 0.6 }}>{c}</span></button>
        ))}
        <button onClick={() => setFavOnly(f => !f)} style={{
          background: favOnly ? skinA.accent : 'transparent',
          color: favOnly ? '#07090a' : skinA.onSurfaceDim,
          border: `1px solid ${favOnly ? skinA.accent : skinA.gridLine}`,
          borderRadius: 6, padding: '6px 10px', fontFamily: skinA.fontMono, fontSize: 10, letterSpacing: '0.1em', cursor: 'pointer', flexShrink: 0, display: 'flex', alignItems: 'center', gap: 4,
        }}>★ FAVS</button>
      </div>
      {/* list */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {filtered.length === 0 && (
          <div style={{ padding: 30, textAlign: 'center', color: skinA.onSurfaceDim, fontFamily: skinA.fontMono, fontSize: 11, letterSpacing: '0.1em' }}>
            — NO MATCHES —
          </div>
        )}
        {filtered.map(x => (
          <div key={x.id} style={{ display: 'flex', padding: '14px 18px', borderBottom: `1px solid ${skinA.gridLine}`, gap: 12 }}>
            <div style={{ width: 34, height: 34, borderRadius: 4, background: skinA.surfaceRaised, border: `1px solid ${skinA.gridLine}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Icon name={x.kind==='wifi'?'wifi':x.kind==='bt'?'bt':'lan'} size={16} color={skinA.accent}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ fontSize: 14, fontWeight: 500, letterSpacing: '-0.01em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{x.name}</div>
                {x.fav && <span style={{ color: skinA.accent, fontSize: 11 }}>★</span>}
              </div>
              {x.label && <div style={{ fontSize: 11, color: skinA.accent, fontFamily: skinA.fontMono, letterSpacing: '0.08em', marginTop: 2 }}>"{x.label}"</div>}
              <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 2 }}>
                {x.id} · {x.meta}
              </div>
            </div>
            <div style={{ textAlign: 'right', fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim }}>
              <div>{x.sessions}× seen</div>
              <div style={{ marginTop: 2, color: skinA.onSurfaceFaint }}>{x.last}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── BLE GATT EXPLORER ────────────────────────────────────

function AGatt({ onBack }) {
  const [openSvc, setOpenSvc] = React.useState('180F');
  const [selChar, setSelChar] = React.useState(null);
  const [connState, setConnState] = React.useState('connected'); // connecting → connected

  return (
    <>
      <div style={{ padding: '12px 18px 14px', borderBottom: `1px solid ${skinA.gridLine}`, background: skinA.surface }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button onClick={onBack} style={{ background: 'transparent', border: `1px solid ${skinA.gridLine}`, color: skinA.onSurface, borderRadius: 4, width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="close" size={14}/>
          </button>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em' }}>BT / GATT</div>
            <div style={{ fontFamily: skinA.fontDisplay, fontSize: 22, letterSpacing: '-0.02em', marginTop: 2 }}>Pixel Buds Pro</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 7, height: 7, borderRadius: '50%', background: skinA.accent, animation: 'blinkA 1s infinite' }}/>
            <span style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.accent, letterSpacing: '0.14em' }}>LINK</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 14, marginTop: 10, fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim }}>
          <div><span style={{ color: skinA.onSurface }}>A4:83:E7:11:22:33</span></div>
          <div><span style={{ color: skinA.onSurface }}>-38</span> dBm</div>
          <div><span style={{ color: skinA.onSurface }}>{GATT_TREE.length}</span> svc</div>
          <div><span style={{ color: skinA.onSurface }}>{GATT_TREE.reduce((a,b)=>a+b.chars.length,0)}</span> chr</div>
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {GATT_TREE.map(svc => (
          <div key={svc.uuid}>
            <button onClick={() => setOpenSvc(openSvc === svc.uuid ? null : svc.uuid)}
              style={{ width: '100%', display: 'flex', alignItems: 'center', padding: '12px 18px', background: 'transparent', border: 'none', borderBottom: `1px solid ${skinA.gridLine}`, cursor: 'pointer', textAlign: 'left', gap: 12 }}>
              <div style={{ width: 42, fontFamily: skinA.fontMono, fontSize: 11, color: skinA.accent }}>0x{svc.uuid}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: skinA.onSurface }}>{svc.name}</div>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 2 }}>{svc.cat} · {svc.chars.length} char</div>
              </div>
              <div style={{ transform: openSvc===svc.uuid ? 'rotate(180deg)' : 'none', transition: 'transform 0.15s' }}>
                <Icon name="chevron" size={14} color={skinA.onSurfaceDim}/>
              </div>
            </button>
            {openSvc === svc.uuid && (
              <div style={{ background: skinA.surfaceRaised, borderBottom: `1px solid ${skinA.gridLine}` }}>
                {svc.chars.map(c => (
                  <button key={c.uuid} onClick={() => setSelChar(c)}
                    style={{ width: '100%', display: 'flex', alignItems: 'center', padding: '10px 18px 10px 34px', background: 'transparent', border: 'none', borderTop: `1px solid ${skinA.gridLine}`, cursor: 'pointer', textAlign: 'left', gap: 12 }}>
                    <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, width: 72 }}>0x{c.uuid}</div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, color: skinA.onSurface, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{c.name}</div>
                      <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, marginTop: 1 }}>{c.value}</div>
                    </div>
                    <div style={{ display: 'flex', gap: 3 }}>
                      {c.props.map(p => (
                        <span key={p} style={{ fontFamily: skinA.fontMono, fontSize: 9, border: `1px solid ${skinA.gridLine}`, color: skinA.onSurfaceDim, borderRadius: 2, padding: '1px 4px', letterSpacing: '0.05em' }}>{p}</span>
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      {selChar && (
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 46, background: skinA.surface, borderTop: `1px solid ${skinA.accent}`, padding: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.accent, letterSpacing: '0.2em' }}>CHARACTERISTIC</div>
            <button onClick={() => setSelChar(null)} style={{ background: 'transparent', border: 'none', color: skinA.onSurfaceDim, cursor: 'pointer' }}><Icon name="close" size={14}/></button>
          </div>
          <div style={{ fontFamily: skinA.fontDisplay, fontSize: 18, letterSpacing: '-0.01em', marginTop: 4 }}>{selChar.name}</div>
          <div style={{ fontFamily: skinA.fontMono, fontSize: 11, color: skinA.onSurfaceDim, marginTop: 2 }}>UUID 0x{selChar.uuid}</div>
          <div style={{ marginTop: 10, padding: '10px 12px', background: skinA.surfaceRaised, border: `1px solid ${skinA.gridLine}`, borderRadius: 4, fontFamily: skinA.fontMono, fontSize: 12, color: skinA.accent }}>
            {selChar.value}
          </div>
        </div>
      )}
    </>
  );
}

// ─── MAP / WARDRIVING ─────────────────────────────────────

function AMap() {
  const [gpsOn, setGpsOn] = React.useState(true);
  const [selected, setSelected] = React.useState(null);
  const sel = WARDRIVING_POINTS.find(p => p.id === selected);

  const trackPath = WARDRIVING_TRACK.map(([x,y],i) => `${i===0?'M':'L'}${(x*100).toFixed(1)} ${(y*100).toFixed(1)}`).join(' ');

  return (
    <>
      <AHeader title="WARDRIVING" subtitle="Geotag"
        stats={[
          { value: WARDRIVING_POINTS.length, label: 'pinned' },
          { value: WARDRIVING_TRACK.length, label: 'fixes' },
          { value: gpsOn ? 'ON' : 'OFF', label: 'gps' },
        ]}
      />
      <div style={{ flex: 1, overflow: 'hidden', position: 'relative' }}>
        {/* fake topo map */}
        <div style={{
          position: 'absolute', inset: 0,
          background: skinA.surfaceRaised,
          backgroundImage: `
            radial-gradient(ellipse at 30% 40%, rgba(110,212,255,0.06), transparent 40%),
            radial-gradient(ellipse at 70% 60%, rgba(200,255,79,0.04), transparent 40%),
            linear-gradient(${skinA.gridLine} 1px, transparent 1px),
            linear-gradient(90deg, ${skinA.gridLine} 1px, transparent 1px)
          `,
          backgroundSize: '100% 100%, 100% 100%, 28px 28px, 28px 28px',
        }}/>
        {/* contour curves */}
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          {[0.3, 0.5, 0.7].map((r, i) => (
            <path key={i} d={`M 0 ${40+i*12} Q 30 ${30+i*10} 50 ${45+i*10} T 100 ${35+i*14}`}
              fill="none" stroke={skinA.gridLine} strokeWidth="0.25"/>
          ))}
          {/* track */}
          <path d={trackPath} fill="none" stroke={skinA.accent2} strokeWidth="0.6" strokeDasharray="2 1.5" opacity="0.7"/>
          {/* points */}
          {WARDRIVING_POINTS.map(p => {
            const color = p.security === 'Open' || p.security === 'WEP' ? skinA.danger
                        : p.security === 'WPA3' ? skinA.accent : skinA.warning;
            return (
              <g key={p.id} onClick={() => setSelected(p.id)} style={{ cursor: 'pointer' }}>
                <circle cx={p.x*100} cy={p.y*100} r="1.2" fill={color} opacity="0.3"/>
                <circle cx={p.x*100} cy={p.y*100} r="0.6" fill={color}/>
                {selected === p.id && <circle cx={p.x*100} cy={p.y*100} r="2" fill="none" stroke={color} strokeWidth="0.3"/>}
              </g>
            );
          })}
          {/* me marker */}
          <g>
            <circle cx={WARDRIVING_TRACK[WARDRIVING_TRACK.length-1][0]*100} cy={WARDRIVING_TRACK[WARDRIVING_TRACK.length-1][1]*100} r="1" fill={skinA.onSurface} stroke={skinA.accent} strokeWidth="0.3"/>
          </g>
        </svg>

        {/* overlay legend top-left */}
        <div style={{
          position: 'absolute', top: 14, left: 14,
          background: 'rgba(7,9,10,0.82)', border: `1px solid ${skinA.gridLine}`,
          backdropFilter: 'blur(6px)', borderRadius: 4, padding: '8px 10px',
          fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.12em',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, background: skinA.accent, borderRadius: '50%' }}/>WPA3
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <div style={{ width: 8, height: 8, background: skinA.warning, borderRadius: '50%' }}/>WPA2
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <div style={{ width: 8, height: 8, background: skinA.danger, borderRadius: '50%' }}/>OPEN/WEP
          </div>
        </div>

        {/* GPS toggle top-right */}
        <button onClick={() => setGpsOn(g => !g)} style={{
          position: 'absolute', top: 14, right: 14,
          background: gpsOn ? skinA.accent : 'rgba(7,9,10,0.82)',
          color: gpsOn ? '#07090a' : skinA.onSurfaceDim,
          border: `1px solid ${gpsOn ? skinA.accent : skinA.gridLine}`,
          borderRadius: 4, padding: '8px 12px', fontFamily: skinA.fontMono, fontSize: 10, letterSpacing: '0.16em', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: gpsOn ? '#07090a' : skinA.onSurfaceDim, animation: gpsOn ? 'blinkA 1.2s infinite' : 'none' }}/>
          GPS {gpsOn?'ON':'OFF'}
        </button>

        {/* detail panel bottom */}
        {sel && (
          <div style={{
            position: 'absolute', left: 14, right: 14, bottom: 14,
            background: 'rgba(7,9,10,0.94)', border: `1px solid ${skinA.accentDim}`, borderRadius: 4,
            padding: 12, backdropFilter: 'blur(8px)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.16em' }}>PINNED</div>
                <div style={{ fontFamily: skinA.fontDisplay, fontSize: 16, marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{sel.ssid}</div>
              </div>
              <button onClick={() => setSelected(null)} style={{ background: 'transparent', border: 'none', color: skinA.onSurfaceDim, cursor: 'pointer', padding: 0 }}><Icon name="close" size={14}/></button>
            </div>
            <div style={{ display: 'flex', gap: 14, marginTop: 6, fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim }}>
              <span><span style={{ color: skinA.onSurface }}>{sel.rssi}</span> dBm</span>
              <span>{sel.security}</span>
              <span>{(sel.x*100).toFixed(2)}°N · {(sel.y*100).toFixed(2)}°E</span>
            </div>
          </div>
        )}

        {/* export FAB */}
        <button style={{
          position: 'absolute', right: 14, bottom: sel ? 94 : 14,
          background: skinA.accent, color: '#07090a', border: 'none',
          borderRadius: 999, padding: '10px 14px', fontFamily: skinA.fontMono, fontSize: 10,
          letterSpacing: '0.16em', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
          transition: 'bottom 0.2s',
        }}>
          <Icon name="download" size={12}/>WIGLE · KML
        </button>
      </div>
    </>
  );
}

// ─── EXPORT DIALOG ────────────────────────────────────────

function AExport({ onClose }) {
  const [fmt, setFmt] = React.useState('csv');
  const [scope, setScope] = React.useState({ wifi: true, bt: true, lan: true });
  const [favOnly, setFavOnly] = React.useState(false);
  const count = (scope.wifi ? INVENTORY.filter(x=>x.kind==='wifi').length : 0) +
                (scope.bt ? INVENTORY.filter(x=>x.kind==='bt').length : 0) +
                (scope.lan ? INVENTORY.filter(x=>x.kind==='lan').length : 0);

  return (
    <div style={{
      position: 'absolute', inset: 0, background: 'rgba(7,9,10,0.85)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'flex-end', zIndex: 10,
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        width: '100%', background: skinA.surface, borderTop: `1px solid ${skinA.accent}`,
        padding: 20, borderRadius: '12px 12px 0 0',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.accent, letterSpacing: '0.2em' }}>EXPORT</div>
            <div style={{ fontFamily: skinA.fontDisplay, fontSize: 22, letterSpacing: '-0.02em', marginTop: 2 }}>Package data</div>
          </div>
          <button onClick={onClose} style={{ background: 'transparent', border: `1px solid ${skinA.gridLine}`, color: skinA.onSurface, borderRadius: 4, width: 30, height: 30, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="close" size={14}/>
          </button>
        </div>
        {/* format */}
        <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em', marginTop: 16 }}>FORMAT</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          {[['csv','CSV','semicolon · UTF-8 BOM'],['json','JSON','with statistics header'],['pdf','PDF','A4 report']].map(([k,l,d]) => (
            <button key={k} onClick={() => setFmt(k)} style={{
              flex: 1, background: fmt===k ? skinA.surfaceHi : skinA.surfaceRaised,
              border: `1px solid ${fmt===k ? skinA.accent : skinA.gridLine}`,
              color: skinA.onSurface, borderRadius: 4, padding: '12px 10px', textAlign: 'left', cursor: 'pointer',
            }}>
              <div style={{ fontFamily: skinA.fontDisplay, fontSize: 16, color: fmt===k ? skinA.accent : skinA.onSurface }}>{l}</div>
              <div style={{ fontFamily: skinA.fontMono, fontSize: 9, color: skinA.onSurfaceDim, marginTop: 3 }}>{d}</div>
            </button>
          ))}
        </div>
        {/* scope */}
        <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.onSurfaceDim, letterSpacing: '0.18em', marginTop: 18 }}>INCLUDE</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
          {[['wifi','WIFI'],['bt','BT'],['lan','LAN']].map(([k,l]) => (
            <button key={k} onClick={() => setScope(s => ({ ...s, [k]: !s[k] }))} style={{
              flex: 1, background: scope[k] ? skinA.accent : 'transparent',
              color: scope[k] ? '#07090a' : skinA.onSurfaceDim,
              border: `1px solid ${scope[k] ? skinA.accent : skinA.gridLine}`,
              borderRadius: 4, padding: '10px 0', fontFamily: skinA.fontMono, fontSize: 11, letterSpacing: '0.14em', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}>{scope[k] && '✓'} {l}</button>
          ))}
        </div>
        {/* favorites */}
        <button onClick={() => setFavOnly(f => !f)} style={{
          marginTop: 10, width: '100%', background: favOnly ? 'rgba(200,255,79,0.08)' : 'transparent',
          color: skinA.onSurface, border: `1px solid ${favOnly ? skinA.accent : skinA.gridLine}`, borderRadius: 4,
          padding: '10px', fontFamily: skinA.fontMono, fontSize: 11, letterSpacing: '0.12em', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <span style={{ width: 14, height: 14, border: `1px solid ${favOnly ? skinA.accent : skinA.onSurfaceDim}`, borderRadius: 2, display: 'flex', alignItems: 'center', justifyContent: 'center', color: skinA.accent, fontSize: 10 }}>{favOnly && '✓'}</span>
          ★ FAVORITES ONLY
        </button>
        {/* action */}
        <button style={{
          marginTop: 20, width: '100%', background: skinA.accent, color: '#07090a', border: 'none',
          padding: '14px 0', fontFamily: skinA.fontMono, fontSize: 12, letterSpacing: '0.2em',
          borderRadius: 4, cursor: 'pointer',
        }}>
          EXPORT {count} ITEMS · {fmt.toUpperCase()} →
        </button>
      </div>
    </div>
  );
}

// ─── ONBOARDING / PERMISSIONS ─────────────────────────────

function AOnboarding({ onDone }) {
  const [step, setStep] = React.useState(0);
  const steps = [
    { kicker: 'SCANNER / 01', title: 'Instrument your airspace.', body: 'This app reads the radio around you — WiFi access points, Bluetooth beacons, devices on your local network. Nothing leaves your phone unless you explicitly export.', cta: 'CONTINUE' },
    { kicker: 'PERMISSIONS / 02', title: 'Grant radio access.', perms: [
      { icon: 'wifi', name: 'Nearby WiFi', desc: 'Scan and identify APs in range.' },
      { icon: 'bt',   name: 'Bluetooth scan', desc: 'Discover classic + BLE devices.' },
      { icon: 'map',  name: 'Location (fine)', desc: 'Required by Android for WiFi/BT. Only used for wardriving when you explicitly enable it.' },
      { icon: 'monitor', name: 'Notifications', desc: 'Status when background monitoring runs.' },
    ], cta: 'GRANT ALL' },
    { kicker: 'READY / 03', title: 'Calibrated.', body: 'Tap Scan on any tab to begin. Channel analysis and security audit refresh automatically after each pass.', cta: 'ENTER →' },
  ];
  const s = steps[step];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', padding: 28, background: skinA.surface }}>
      {/* step ticks */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 30 }}>
        {steps.map((_, i) => (
          <div key={i} style={{ flex: 1, height: 2, background: i <= step ? skinA.accent : skinA.gridLine, transition: 'background 0.2s' }}/>
        ))}
      </div>
      <div style={{ fontFamily: skinA.fontMono, fontSize: 10, color: skinA.accent, letterSpacing: '0.24em' }}>{s.kicker}</div>
      <div style={{ fontFamily: skinA.fontDisplay, fontSize: 38, fontWeight: 500, letterSpacing: '-0.03em', lineHeight: 1.05, marginTop: 10 }}>
        {s.title}
      </div>
      {s.body && (
        <div style={{ fontSize: 14, color: skinA.onSurfaceDim, marginTop: 14, lineHeight: 1.5 }}>{s.body}</div>
      )}
      {s.perms && (
        <div style={{ marginTop: 20 }}>
          {s.perms.map((p, i) => (
            <div key={i} style={{ display: 'flex', gap: 14, padding: '14px 0', borderBottom: `1px solid ${skinA.gridLine}` }}>
              <div style={{ width: 30, height: 30, borderRadius: 4, border: `1px solid ${skinA.gridLine}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon name={p.icon} size={14} color={skinA.accent}/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: skinA.onSurface }}>{p.name}</div>
                <div style={{ fontSize: 11, color: skinA.onSurfaceDim, marginTop: 2, lineHeight: 1.4 }}>{p.desc}</div>
              </div>
            </div>
          ))}
        </div>
      )}
      <div style={{ flex: 1 }}/>
      <button onClick={() => step < steps.length-1 ? setStep(step+1) : onDone()}
        style={{ background: skinA.accent, color: '#07090a', border: 'none', padding: '16px 0', fontFamily: skinA.fontMono, fontSize: 12, letterSpacing: '0.2em', borderRadius: 4, cursor: 'pointer' }}>
        {s.cta}
      </button>
      {step > 0 && step < steps.length-1 && (
        <button onClick={() => setStep(step-1)} style={{ marginTop: 10, background: 'transparent', color: skinA.onSurfaceDim, border: 'none', padding: '8px 0', fontFamily: skinA.fontMono, fontSize: 10, letterSpacing: '0.16em', cursor: 'pointer' }}>
          ← BACK
        </button>
      )}
    </div>
  );
}

Object.assign(window, {
  AWifiDetail, AInventory, AGatt, AMap, AExport, AOnboarding,
});
